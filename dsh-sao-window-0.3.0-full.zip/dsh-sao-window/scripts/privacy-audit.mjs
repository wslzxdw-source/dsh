/**
 * 发布前隐私/敏感信息审计：检查插件目录里有没有不该跟着进公开仓库的东西。
 *
 * 为什么单独写一个：这类东西手查必漏。实测就在一个"看起来没问题"的
 * assets/link-start.m4a 里查出过剪辑软件写入的项目元数据
 * （videoId / product / os / 声音克隆标记）。
 *
 * 用法：
 *   node scripts/privacy-audit.mjs
 *   node scripts/privacy-audit.mjs --root <插件目录>
 */
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs'
import path from 'node:path'

const ROOT = process.argv.includes('--root')
  ? path.resolve(process.argv[process.argv.indexOf('--root') + 1])
  : path.resolve(import.meta.dirname, '..')

const TEXT_EXT = new Set(['.js', '.mjs', '.cjs', '.json', '.yml', '.yaml', '.py', '.md', '.txt', '.html', '.css'])
const BINARY_EXT = new Set(['.png', '.jpg', '.jpeg', '.webp', '.gif', '.m4a', '.mp3', '.ogg', '.wav', '.mp4'])

let problems = 0
let warnings = 0
function bad(msg, extra) {
  problems++
  console.log('  ✗ ' + msg)
  if (extra) console.log('      ' + extra)
}
function warn(msg, extra) {
  warnings++
  console.log('  ! ' + msg)
  if (extra) console.log('      ' + extra)
}
function ok(msg) { console.log('  ✓ ' + msg) }

function walk(dir, out = []) {
  for (const name of readdirSync(dir)) {
    if (name === 'node_modules' || name === '.git') continue
    const p = path.join(dir, name)
    const st = statSync(p)
    if (st.isDirectory()) walk(p, out)
    else out.push({ path: p, rel: path.relative(ROOT, p), size: st.size })
  }
  return out
}

// ---------- 文本规则 ----------
// 每条：名称 · 正则 · 级别（bad = 必须处理，warn = 请人工确认）
const TEXT_RULES = [
  { name: '本机用户名 / 家目录绝对路径', level: 'bad', re: /[A-Za-z]:\\\\?Users\\\\?[A-Za-z0-9._-]+|\/home\/[A-Za-z0-9._-]+|\/Users\/[A-Za-z0-9._-]+/ },
  { name: '疑似 API key', level: 'bad', re: /sk-[A-Za-z0-9]{12,}/ },
  { name: '疑似 token / 会话 cookie', level: 'bad', re: /dsh-auth-[A-Za-z0-9]|(?:access|refresh|session)[_-]?token\s*[:=]\s*["'][^"']{8,}/i },
  { name: '硬编码密码', level: 'bad', re: /(?:password|passwd|secret)\s*[:=]\s*["'][^"']{3,}["']/i },
  { name: '疑似真实余额数字', level: 'warn', re: /14\.098898|¥14\.10|7\.46|7\.51/ },
  { name: '个人文件名（中文/桌面）', level: 'warn', re: /10月2日|Desktop\\\\|C:\\\\Users\\\\[^\\\\]+\\\\Desktop/ },
  { name: '疑似机器 / 会话标识', level: 'warn', re: /anonymousUserId|machineId|deviceId|sessionId\s*[:=]/ },
]

// ---------- 二进制资产里的元数据（最容易漏）----------
// 从媒体/图片文件里抽可见字符串，再按关键字判断。
const ASSET_NEEDLES = [
  { needle: 'udta', why: '媒体元数据容器（可能含软件写入的个人信息）' },
  { needle: 'ilst', why: 'iTunes 风格元数据（项目 ID / 软件标识常在这里）' },
  { needle: 'editType', why: '剪辑软件项目元数据' },
  { needle: 'videoId', why: '剪辑软件项目唯一 ID' },
  { needle: 'douyin_beauty_me', why: '剪映美颜标记' },
  { needle: 'is_use_vc_sing_clone', why: '声音克隆使用标记' },
  { needle: 'Lavf', why: '导出工具链版本（可接受，但值得知道）' },
]

function stringsOf(buf, min = 6) {
  const out = []
  let cur = ''
  for (const b of buf) {
    if (b >= 0x20 && b < 0x7f) cur += String.fromCharCode(b)
    else { if (cur.length >= min) out.push(cur); cur = '' }
  }
  if (cur.length >= min) out.push(cur)
  return out
}

console.log('dsh-sao-window · 发布前隐私审计')
console.log('目录：' + ROOT)
console.log('')

if (!existsSync(ROOT)) { console.log('  ✗ 目录不存在'); process.exit(1) }
const files = walk(ROOT)
console.log(`扫描 ${files.length} 个文件……`)

// ---- 1. 文本文件 ----
console.log('')
console.log('文本内容：')
let textHits = 0
const SELF = path.resolve(import.meta.filename)
for (const f of files) {
  // 跳过审计脚本自己 —— 它的 TEXT_RULES 里就写着这些模式，扫自己必然假阳性
  if (path.resolve(f.path) === SELF) continue
  if (!TEXT_EXT.has(path.extname(f.path).toLowerCase())) continue
  let text
  try { text = readFileSync(f.path, 'utf8') } catch { continue }
  const lines = text.split('\n')
  for (const rule of TEXT_RULES) {
    lines.forEach((line, i) => {
      const m = line.match(rule.re)
      if (!m) return
      textHits++
      const where = `${f.rel}:${i + 1}`
      const snippet = line.trim().slice(0, 100)
      if (rule.level === 'bad') bad(`${rule.name} → ${where}`, snippet)
      else warn(`${rule.name} → ${where}`, snippet)
    })
  }
}
if (textHits === 0) ok('未发现用户名 / 路径 / 密钥 / 真实余额')

// ---- 2. 二进制资产元数据 ----
console.log('')
console.log('二进制资产元数据：')
for (const f of files) {
  const ext = path.extname(f.path).toLowerCase()
  if (!BINARY_EXT.has(ext)) continue
  const buf = readFileSync(f.path)
  const strs = stringsOf(buf)
  const joined = strs.join('\n')
  const hit = ASSET_NEEDLES.filter((n) => joined.includes(n.needle))
  // png 的 tEXt/iTXt 块
  const isPng = ext === '.png'
  const pngMeta = isPng && (buf.includes(Buffer.from('tEXt')) || buf.includes(Buffer.from('iTXt')) || buf.includes(Buffer.from('zTXt')))
  if (hit.length === 0 && !pngMeta) {
    ok(`${f.rel}（${f.size} 字节）干净`)
    continue
  }
  if (pngMeta) bad(`${f.rel} 含 PNG 文本元数据块（tEXt/iTXt/zTXt）—— 可能含生成提示词/软件信息`)
  for (const h of hit) {
    // Lavf 只是工具链版本，属可接受信息
    if (h.needle === 'Lavf') warn(`${f.rel} 含 ${h.needle}（${h.why}）`)
    else bad(`${f.rel} 含 ${h.needle} —— ${h.why}`)
  }
}

// ---- 3. 常见遗漏：自检产物 ----
console.log('')
console.log('自检产物 / 杂物：')
const junk = files.filter((f) => /\.browser-shot|\.log$|\.bak$|Thumbs\.db|\.DS_Store/.test(f.rel))
if (junk.length) {
  for (const j of junk) bad(`不该发布的产物：${j.rel}（${j.size} 字节）`)
} else {
  ok('无截图 / 日志 / 备份残留')
}
if (!existsSync(path.join(ROOT, '.gitignore'))) warn('没有 .gitignore（建议加上，至少忽略自检截图与 node_modules）')
else ok('有 .gitignore')

// ---- 汇总 ----
console.log('')
if (problems === 0 && warnings === 0) {
  console.log('审计通过 ✓（无问题、无待确认项）')
} else if (problems === 0) {
  console.log(`审计通过 ✓（${warnings} 项待人工确认）`)
} else {
  console.log(`${problems} 项必须处理 ✗ · ${warnings} 项待确认`)
}
console.log('')
console.log('提示：审计只能查"已知模式"。发布前还请人工过一遍：')
console.log('  · assets/ 里的素材你是否有权分发（音频/立绘往往有版权）')
console.log('  · README 里的示例数字、路径是否已经换成占位符')
process.exit(problems === 0 ? 0 : 1)
