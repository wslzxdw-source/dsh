// ---------------------------------------------------------------------------
// dsh-sao-window —— 桥运行时语法与自愈检查
//
// BRIDGE_RUNTIME 是宿主半侧里的一段模板字符串，会被下发给浏览器执行。
// 它不参与宿主模块的语法检查，所以必须单独验一遍（否则里面的错误只有用户能看到）。
//
// 运行：node scripts/bridge-check.mjs
// ---------------------------------------------------------------------------

import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const HERE = path.dirname(fileURLToPath(import.meta.url))
const HOST = path.join(HERE, '..', 'lib', 'index.js')
const src = fs.readFileSync(HOST, 'utf8')

let failures = 0
const ok = (s) => console.log('  \u2713 ' + s)
const bad = (s) => { failures += 1; console.log('  \u2717 ' + s) }

// 抽出 BRIDGE_RUNTIME 模板字面量
const marker = 'const BRIDGE_RUNTIME = `'
const start = src.indexOf(marker)
if (start < 0) { bad('找不到 BRIDGE_RUNTIME'); process.exit(1) }
const end = src.indexOf('\n`\n', start)
if (end < 0) { bad('BRIDGE_RUNTIME 没有正常收尾'); process.exit(1) }
let body = src.slice(start + marker.length, end)

// 把两个 ${JSON.stringify(...)} 内插替换成真实值（等价于宿主下发时的渲染结果）
const before = body
body = body.replace(/\$\{JSON\.stringify\(ROUTE_PREFIX\)\}/g, '"/dsh-sao"')
body = body.replace(/\$\{JSON\.stringify\(BRIDGE_LABEL\)\}/g, '"DS 悬浮窗"')
console.log('桥运行时：')
if (body === before) bad('没有替换到内插表达式（模板可能被改坏了）')
else ok('两个内插表达式都替换成功')

try {
  // eslint-disable-next-line no-new-func
  new Function(body)
  ok('语法合法（new Function 通过，' + body.length + ' 字符）')
} catch (err) {
  bad('语法错误：' + String((err && err.message) || err))
}

// 自愈能力：应当暴露 destroy，而不是一个「第二次直接 return」的守卫
if (body.includes('__dshSaoBridgeDestroy')) ok('暴露 __dshSaoBridgeDestroy（重复载入时自愈）')
else bad('缺少 __dshSaoBridgeDestroy —— 第二次载入会静默失效')

if (/if \(window\.__dshSaoBridgeRuntime\) return/.test(body)) {
  bad('仍有「第二次直接 return」的旧守卫 —— 必须改成自愈')
} else {
  ok('没有「第二次直接 return」的旧守卫')
}

// 关键行为：桥只负责把浮层自己的圆钮接上，不依赖任何第三方挂件
for (const [label, needle] of [
  ['把圆钮点击翻译成 dsh-sao:toggle', 'dsh-sao:toggle'],
  ['按 .sao-launcher 找入口圆钮', 'sao-launcher'],
  ['绑定命中区标记 data-sao-window-hit', 'data-sao-window-hit'],
  ['用 MutationObserver 跟随 DOM 变化', 'MutationObserver'],
  ['有轮询兜底（float.js 可能晚一步到）', 'setInterval'],
  ['桥进展会上报给浮层', 'dsh-sao:bridge'],
]) {
  if (body.includes(needle)) ok(label)
  else bad('缺少：' + label)
}

// 独立化断言：桥里不该再出现任何 whale 痕迹
for (const needle of ['dsh-whale', 'findWhale', 'whale']) {
  if (body.includes(needle)) bad('桥里还残留 whale 依赖：' + needle)
}
ok('桥已与 dsh-whale-widget 完全解耦（无 whale 痕迹）')

// float.js 的自愈与清理
const float = fs.readFileSync(path.join(HERE, '..', 'lib', 'float.js'), 'utf8')
console.log('')
console.log('悬浮窗脚本：')
if (float.includes('__dshSaoFloatDestroy')) ok('暴露 __dshSaoFloatDestroy（重复载入时自愈）')
else bad('缺少 __dshSaoFloatDestroy')
if (/if \(window\.__dshSaoFloat\) return/.test(float)) bad('仍有「第二次直接 return」的旧守卫')
else ok('没有「第二次直接 return」的旧守卫')
// 样式表选择器必须在 ensureCss 与 destroy 之间共用同一个常量，
// 否则会「一个写 style[...]、另一个写 [...]」，旧样式表永远摘不掉。
if (/var CSS_SELECTOR = '\[data-plugin-css=/.test(float)) ok('样式选择器抽成了 CSS_SELECTOR 常量')
else bad('样式选择器没有抽成常量（两处写法容易不一致）')
if (float.includes('st.parentNode.removeChild(st)')) ok('销毁时会摘掉注入的样式表')
else bad('销毁时没有清理样式表')
if (/querySelector\('style\[data-plugin-css/.test(float)) bad('仍有写死成 style[...] 的选择器')
else ok('没有写死成 style[...] 的选择器')

// 立绘：现在是**抠好的透明底原图**，绝不能再套 brightness(0)/invert（会变成剪影）
const silRule = (float.match(/\.sao-silhouette\{[^}]*\}/) || [''])[0]
if (!silRule) bad('CSS 里找不到 .sao-silhouette 规则')
else if (/invert\(/.test(silRule)) bad('.sao-silhouette 里还有 invert')
else if (/brightness\(0\)/.test(silRule)) bad('.sao-silhouette 里还有 brightness(0)（会变成剪影，用户要的是原图）')
else if (!/drop-shadow/.test(silRule)) bad('.sao-silhouette 没有 drop-shadow（缺少层次）')
else ok('立绘保留原色、只做投影（不压剪影）')

// 抠图脚本得在，方便以后换图
if (fs.existsSync(path.join(HERE, '..', 'scripts', 'extract-character.py'))) ok('抠图脚本在位（scripts/extract-character.py）')
else bad('缺少抠图脚本 extract-character.py')

// 菜单项必须有可见反馈：信息面板 + 卡片内提示条
for (const [label, needle] of [
  ['有卡片内信息面板（.sao-info）', '.sao-info{'],
  ['有点击提示条（.sao-toast）', '.sao-toast{'],
  ['二级菜单会调 openInfo()', 'openInfo()'],
]) {
  if (float.includes(needle)) ok(label)
  else bad('缺少：' + label)
}

console.log('')
console.log(failures === 0 ? '全部通过 \u2713' : failures + ' 项失败 \u2717')
process.exit(failures === 0 ? 0 : 1)
