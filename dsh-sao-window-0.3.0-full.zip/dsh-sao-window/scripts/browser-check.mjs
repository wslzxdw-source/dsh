/**
 * 真实浏览器自检：用 Chrome 打开一个与 DSH 页面等价的测试页，
 * 真的去点那个圆钮，然后把结果读回来。
 *
 * 为什么非要在真浏览器里跑：
 *   之前用手写假 DOM 测过，但那个假 DOM 的 getBoundingClientRect() 返回固定值，
 *   等于"假装位置永远正确"，于是"窗口跑到视口外""图加载失败"这类 bug
 *   在沙箱里全都测不出来。真实调试点不开，就必须上真浏览器。
 *
 * 做法：
 *   1. 起一个本地代理（随机端口），页面与 /dsh-sao/* 资源都从它取；
 *      资源从正在运行的 DSH 实例（默认 127.0.0.1:19387）转发过来。
 *      —— 同源，所以不触发插件的 fail-closed 信任栅栏，也不用登录 token。
 *   2. 用 Chrome 的 --remote-debugging-port + CDP（Node 24 自带 WebSocket）打开页面。
 *   3. 等页面里的 [data-sao-selftest] 出现，读 JSON。
 *   4. 顺便截图，方便人眼确认。
 *
 * 用法：node scripts/browser-check.mjs [--keep] [--shot out.png]
 */
import { createServer } from 'node:http'
import { spawn } from 'node:child_process'
import { mkdtempSync, existsSync, writeFileSync, readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'

const ROOT = path.resolve(import.meta.dirname, '..')
const DSH = process.env.SAO_DSH_ORIGIN || 'http://127.0.0.1:19387'
const KEEP = process.argv.includes('--keep')
const NOBRIDGE = process.argv.includes('--nobridge')
// --noaudio：让 /dsh-sao/link-start 一律 404，模拟"插件不带自备音频"
// ——也就是**新装用户的默认情况**，必须回退到合成音（这里曾经完全没声音）
const NOAUDIO = process.argv.includes('--noaudio')
const shotIdx = process.argv.indexOf('--shot')
// 截图默认写到**系统临时目录**，不写进仓库。
// 原因：面板上就显示余额，截图会把运行者的真实余额一起拍进去，
// 落在仓库里很容易连着 commit 被推上公开仓库。
const SHOT_PATH = shotIdx >= 0
  ? path.resolve(process.argv[shotIdx + 1])
  : path.join(tmpdir(), 'dsh-sao-browser-shot.png')

const CHROMES = [
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
]

let pass = 0
let fail = 0
function ok(msg) { console.log('  ✓ ' + msg); pass++ }
function bad(msg) { console.log('  ✗ ' + msg); fail++ }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

// ---------- 1. 代理服务器：页面 + 资源都同源 ----------
// 音频探针：必须在 float.js **之前**执行，包住 AudioContext.prototype.createOscillator，
// 这样"开窗到底有没有出声、出的是不是上行扫频 + 大三和弦"就是实测而不是推测。
const AUDIO_PROBE = `(function () {
  var rec = { created: 0, freqs: [], audioEls: 0, elSrc: null, elReadyState: null,
    elDuration: null, elError: null, playCalls: 0, realPlayCalls: 0, pauses: 0, playLog: [] }
  window.__saoAudio = rec
  try {
    var AC = window.AudioContext || window.webkitAudioContext
    if (AC && AC.prototype && AC.prototype.createOscillator) {
      var orig = AC.prototype.createOscillator
      AC.prototype.createOscillator = function () {
        rec.created++
        var osc = orig.apply(this, arguments)
        try {
          var f = osc.frequency
          var origSet = f.setValueAtTime.bind(f)
          f.setValueAtTime = function (v, t) {
            if (rec.freqs.length < 40) rec.freqs.push(v)
            return origSet(v, t)
          }
        } catch (e) {}
        return osc
      }
    }
    // 包住 Audio 构造器：要能区分"用了自备音频"还是"回退到合成音"，
    // 并记录加载结果（readyState / duration / error）与 play() 调用次数
    var OrigAudio = window.Audio
    if (OrigAudio) {
      var Wrapped = function () {
        rec.audioEls++
        var el = new OrigAudio()
        try {
          Object.defineProperty(el, 'src', {
            configurable: true,
            get: function () { return el.getAttribute('src') || '' },
            set: function (v) {
              rec.elSrc = v
              el.setAttribute('src', v)
              el.addEventListener('loadedmetadata', function () {
                rec.elReadyState = el.readyState
                rec.elDuration = el.duration
              })
              el.addEventListener('canplaythrough', function () {
                rec.elReadyState = el.readyState
                rec.elDuration = el.duration
              })
              el.addEventListener('error', function () {
                rec.elError = 'media error code ' + (el.error && el.error.code)
              })
            },
          })
        } catch (e) { rec.probeErr = String((e && e.message) || e) }
        var origPlay = OrigAudio.prototype.play
        if (origPlay) {
          el.play = function () {
            rec.playCalls++
            // 预热探针是 muted 的，不该算进"真实播放"。
            // 直接读原生 getter 的当前值 —— el.muted 在包装对象上取不到。
            var isMuted = false
            try {
              var d = Object.getOwnPropertyDescriptor(OrigAudio.prototype, 'muted')
              isMuted = d && d.get ? d.get.call(el) : !!el.muted
            } catch (e) { isMuted = !!el.muted }
            if (!isMuted) rec.realPlayCalls++
            rec.playLog.push((isMuted ? 'muted' : 'SOUND') + ':rs' + el.readyState + ':dur' + el.duration + ':' + (el.currentSrc || el.src || '?'))
            return origPlay.apply(el, arguments)
          }
        }
        var origPause = OrigAudio.prototype.pause
        if (origPause) {
          el.pause = function () { rec.pauses++; return origPause.apply(el, arguments) }
        }
        return el
      }
      Wrapped.prototype = OrigAudio.prototype
      window.Audio = Wrapped
    }
  } catch (e) { rec.err = String((e && e.message) || e) }
})()`

function buildPage(withBridge) {
  const scenario = `(function () {
  var out = { steps: [], errors: [] }
  function log(k, v) { out.steps.push(k + '=' + v) }
  function safe(label, fn) {
    try { return fn() } catch (e) { out.errors.push(label + ': ' + String((e && e.message) || e)); return null }
  }
  window.addEventListener('error', function (e) {
    out.errors.push('window.onerror: ' + e.message + ' @' + (e.filename || '') + ':' + e.lineno)
  })
  window.addEventListener('unhandledrejection', function (e) {
    out.errors.push('unhandledrejection: ' + String((e.reason && e.reason.message) || e.reason))
  })
  function rectOf(n) {
    var r = n.getBoundingClientRect()
    return Math.round(r.left) + ',' + Math.round(r.top) + ' ' + Math.round(r.width) + 'x' + Math.round(r.height)
  }
  function finish() {
    var el = document.createElement('div')
    el.setAttribute('data-sao-selftest', '1')
    el.style.cssText = 'position:fixed;left:-99999px;top:0;white-space:pre'
    el.textContent = JSON.stringify(out)
    document.body.appendChild(el)
  }
  // 数一次点击到底触发了几次 toggle —— 在 float.js 之前挂钩，记录来源
  var toggleEvents = 0
  window.__saoToggleFrom = []
  window.addEventListener('dsh-sao:toggle', function (e) {
    toggleEvents++
    if (window.__saoToggleFrom.length < 8) window.__saoToggleFrom.push('#' + toggleEvents)
  })
  // 也监听桥的上报，看桥是否重复绑定
  window.addEventListener('dsh-sao:bridge', function (e) {
    if (window.__saoToggleFrom.length < 8) window.__saoToggleFrom.push('bridge:' + ((e.detail || {}).text || ''))
  })
  function clickOrb() {
    var o = document.querySelector('.sao-launcher')
    window.__saoToggleFrom.push('--click--')
    o.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }))
  }
  setTimeout(function () {
    var win = document.querySelector('[data-sao-window]')
    var orb = document.querySelector('.sao-launcher')
    log('floatWindow', !!win)
    log('orb', !!orb)
    if (!orb) { out.errors.push('没有圆钮 —— float.js 可能没跑'); finish(); return }
    log('orbBox', rectOf(orb))
    var img = orb.querySelector('img')
    if (img) {
      log('orbImg', img.currentSrc || img.src)
      log('orbImgNatural', img.naturalWidth + 'x' + img.naturalHeight)
      if (img.complete && img.naturalWidth === 0) out.errors.push('圆钮图片加载失败（naturalWidth=0）')
    } else out.errors.push('圆钮里没有 <img>')

    // ① 点击图标 → 应当"开"，并且响一声。
    //    "响一声"有两条路：自备音频（数 <audio>.play）或合成音（数振荡器）。
    //    下面两个计数都取**每次点击的增量**，最后按"走的是哪条路"判定。
    window.__saoAudio.created = 0
    window.__saoAudio.freqs.length = 0
    var pc1 = window.__saoAudio.playCalls
    var pg1 = window.__saoAudio.playLog.length
    safe('click1', clickOrb)
    log('afterClick1', win ? win.style.display : 'no-win')
    log('soundsAfterClick1', String(window.__saoAudio.playLog.slice(pg1).filter(function (x) { return x.indexOf('SOUND') === 0 }).length))
    log('playDelta1', String(window.__saoAudio.playCalls - pc1))
    log('oscillatorsAfterClick1', window.__saoAudio.created)
    log('audioElsAfterClick1', window.__saoAudio.audioEls)
    log('freqsAfterClick1', (window.__saoAudio.freqs || []).slice(0, 12).join(','))
    log('audioSrc', String(window.__saoAudio.elSrc))
    log('audioReadyState', String(window.__saoAudio.elReadyState))
    log('audioDuration', String(window.__saoAudio.elDuration))
    log('audioError', String(window.__saoAudio.elError))
    log('audioPlayCalls', String(window.__saoAudio.playCalls))
    log('audioPauses', String(window.__saoAudio.pauses))
    log('playLog', JSON.stringify(window.__saoAudio.playLog))
    log('toggleEventsAfterClick1', toggleEvents)
    log('toggleFrom', JSON.stringify(window.__saoToggleFrom))
    log('orbBridged', String(orb.getAttribute('data-sao-bridged')))
    // 有几个入口？桥标记的是哪一个？（曾经出现"桥标记 A、被点的是 B"）
    var allOrbs = Array.prototype.slice.call(document.querySelectorAll('.sao-launcher'))
    log('orbCount', allOrbs.length)
    log('orbFlags', JSON.stringify(allOrbs.map(function (o) {
      return (o === orb ? 'picked' : 'other') + ':bridged=' + o.getAttribute('data-sao-bridged')
        + ':connected=' + !!o.isConnected
    })))
    log('floatWindowCount', document.querySelectorAll('[data-sao-window]').length)
    log('stageCount', document.querySelectorAll('[data-sao-stage]').length)
    // ② 再点一次 → 应当"关"，并且**也要响一声**（每次点图标都出声）
    setTimeout(function () {
      var pg2 = window.__saoAudio.playLog.length
      var oc2 = window.__saoAudio.created
      safe('click2', clickOrb)
      log('afterClick2', win ? win.style.display : 'no-win')
      log('soundsAfterClick2', String(window.__saoAudio.playLog.slice(pg2).filter(function (x) { return x.indexOf('SOUND') === 0 }).length))
      log('oscillatorsDelta2', window.__saoAudio.created - oc2)
      log('toggleEventsTotal', toggleEvents)
      // ③ 第三次 → 应当又"开"
      setTimeout(function () {
        var pg3 = window.__saoAudio.playLog.length
        var oc3 = window.__saoAudio.created
        safe('click3', clickOrb)
        log('afterClick3', win ? win.style.display : 'no-win')
        log('soundsAfterClick3', String(window.__saoAudio.playLog.slice(pg3).filter(function (x) { return x.indexOf('SOUND') === 0 }).length))
        log('oscillatorsDelta3', window.__saoAudio.created - oc3)
        setTimeout(function () {
          if (win) {
            var cs = getComputedStyle(win)
            var r = win.getBoundingClientRect()
            log('finalDisplay', win.style.display)
            log('finalComputed', cs.display + '/' + cs.visibility + '/op' + cs.opacity)
            log('finalBox', rectOf(win))
            log('inViewport', (r.right > 24 && r.bottom > 24 && r.left < innerWidth - 24 && r.top < innerHeight - 24))
            log('innerSize', innerWidth + 'x' + innerHeight)
            log('mainChildren', win.querySelectorAll('.sao-main > *').length)
            log('hud', !!win.querySelector('.sao-hud'))
            log('silhouette', !!win.querySelector('.sao-silhouette'))
            log('balanceText', ((win.querySelector('.sao-bal-val') || {}).textContent || '').trim())
          }
          log('marker', ((document.querySelector('[data-sao-stage]') || {}).textContent || '(none)'))
          finish()
        }, 400)
      }, 400)
    }, 400)
  }, 800)
})()`
  const bridgeTag = withBridge ? '<script src="/dsh-sao/bridge.js"></script>\n' : ''
  return `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>sao 自检</title>
<style>html,body{margin:0;font:13px system-ui;background:#f4f6f7;color:#333}</style></head>
<body>
<h3 style="margin:12px">dsh-sao-window · 真实浏览器自检${withBridge ? '' : '（不含 bridge.js）'}</h3>
<img src="/dsh-sao/character.png" width="72" height="75" alt="" style="margin:12px">
<script>${AUDIO_PROBE}</script>
<script src="/dsh-sao/float.js"></script>
${bridgeTag}<script>${scenario}</script>
</body></html>`
}

function startProxy() {
  return new Promise((resolve) => {
    const srv = createServer(async (req, res) => {
      const url = String(req.url || '/')
      if (url === '/' || url.startsWith('/?')) {
        // ?nobridge=1 → 只加载 float.js，用来把"两次 toggle"定位到具体来源
        const withBridge = url.indexOf('nobridge=1') === -1
        const html = buildPage(withBridge)
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' })
        res.end(html)
        return
      }
      if (url.startsWith('/dsh-sao/')) {
        // 自备音频优先从磁盘读：
        // 宿主不热重载，运行中的实例可能还没有 /dsh-sao/link-start 路由（404）。
        // 直接从 assets/ 供文件，才能真实检验"这个音频到底能不能播"。
        if (url.split('?')[0] === '/dsh-sao/link-start') {
          if (NOAUDIO) {
            res.writeHead(404, { 'Content-Type': 'text/plain' })
            res.end('no custom link-start audio (forced by --noaudio)')
            return
          }
          const MIME = { '.ogg': 'audio/ogg', '.mp3': 'audio/mpeg', '.m4a': 'audio/mp4', '.wav': 'audio/wav' }
          for (const ext of ['.ogg', '.mp3', '.m4a', '.wav']) {
            const p = path.join(ROOT, 'assets', 'link-start' + ext)
            if (existsSync(p)) {
              const buf = readFileSync(p)
              res.writeHead(200, {
                'Content-Type': MIME[ext],
                'Cache-Control': 'no-store',
                'Content-Length': String(buf.length),
                'Accept-Ranges': 'bytes',
              })
              res.end(buf)
              return
            }
          }
          res.writeHead(404, { 'Content-Type': 'text/plain' })
          res.end('no custom link-start audio')
          return
        }
        try {
          const r = await fetch(DSH + url, { signal: AbortSignal.timeout(8000) })
          const buf = Buffer.from(await r.arrayBuffer())
          res.writeHead(r.status, {
            'Content-Type': r.headers.get('content-type') || 'application/octet-stream',
            'Cache-Control': 'no-store',
            'Content-Length': String(buf.length),
          })
          res.end(buf)
        } catch (err) {
          res.writeHead(502, { 'Content-Type': 'text/plain' })
          res.end('proxy error: ' + String((err && err.message) || err))
        }
        return
      }
      res.writeHead(404, { 'Content-Type': 'text/plain' })
      res.end('not found')
    })
    srv.listen(0, '127.0.0.1', () => resolve({ srv, port: srv.address().port }))
  })
}

// ---------- 2. 极简 CDP 客户端 ----------
class Cdp {
  constructor(ws) { this.ws = ws; this.id = 0; this.pending = new Map() }
  static async connect(wsUrl) {
    const ws = new WebSocket(wsUrl)
    await new Promise((res, rej) => {
      ws.addEventListener('open', res, { once: true })
      ws.addEventListener('error', () => rej(new Error('CDP WebSocket 连接失败')), { once: true })
    })
    const c = new Cdp(ws)
    ws.addEventListener('message', (ev) => {
      let msg
      try { msg = JSON.parse(ev.data) } catch { return }
      if (msg.id && c.pending.has(msg.id)) {
        const { resolve, reject } = c.pending.get(msg.id)
        c.pending.delete(msg.id)
        if (msg.error) reject(new Error(msg.error.message || JSON.stringify(msg.error)))
        else resolve(msg.result)
      }
    })
    return c
  }
  send(method, params = {}) {
    const id = ++this.id
    this.ws.send(JSON.stringify({ id, method, params }))
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject })
      setTimeout(() => {
        if (this.pending.has(id)) { this.pending.delete(id); reject(new Error('CDP 超时: ' + method)) }
      }, 20000)
    })
  }
  async eval(expression) {
    const r = await this.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
    if (r.exceptionDetails) throw new Error('页面内异常: ' + JSON.stringify(r.exceptionDetails.exception || r.exceptionDetails))
    return r.result.value
  }
  close() { try { this.ws.close() } catch {} }
}

// ---------- 3. 主流程 ----------
async function freePort() {
  const { srv, port } = await startProxy()
  return { srv, port }
}

async function main() {
  console.log('dsh-sao-window · 真实浏览器自检（Chrome + CDP）')
  console.log('DSH 实例：' + DSH)

  const chrome = CHROMES.find((p) => existsSync(p))
  if (!chrome) { bad('找不到 Chrome / Edge'); process.exit(1) }
  console.log('浏览器：' + chrome)

  const { srv, port } = await freePort()
  const nobridge = NOBRIDGE
  const url = `http://127.0.0.1:${port}/?selftest=1` + (nobridge ? '&nobridge=1' : '')
  console.log('测试页：' + url)
  console.log('')

  const profile = mkdtempSync(path.join(tmpdir(), 'sao-chrome-'))
  const dbgPort = 40000 + Math.floor(Math.random() * 9000)
  const child = spawn(chrome, [
    '--headless=new',
    '--disable-gpu',
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-extensions',
    '--disable-background-networking',
    '--window-size=1440,900',
    '--user-data-dir=' + profile,
    '--remote-debugging-port=' + dbgPort,
    '--remote-allow-origins=*',
    url,
  ], { stdio: 'ignore', detached: false })

  let cdp = null
  try {
    // 等 DevTools 端点起来
    let wsUrl = null
    for (let i = 0; i < 60 && !wsUrl; i++) {
      await sleep(500)
      try {
        const list = await (await fetch(`http://127.0.0.1:${dbgPort}/json/list`, { signal: AbortSignal.timeout(3000) })).json()
        const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl)
        if (page) wsUrl = page.webSocketDebuggerUrl
      } catch {}
    }
    if (!wsUrl) throw new Error('拿不到 DevTools 端点（Chrome 可能没起来）')
    cdp = await Cdp.connect(wsUrl)
    await cdp.send('Page.enable')
    await cdp.send('Runtime.enable')

    // 等页面里的自检结果
    let raw = null
    for (let i = 0; i < 80; i++) {
      await sleep(500)
      try {
        raw = await cdp.eval("(function(){var e=document.querySelector('[data-sao-selftest]');return e?e.textContent:null})()")
      } catch (e) { /* 页面可能还在导航 */ }
      if (raw) break
    }
    if (!raw) throw new Error('页面没有产出自检结果（脚本可能没跑起来）')
    const out = JSON.parse(raw)

    // 截图（存证）：整页 + 单独的入口图标区域（人眼确认图标好不好看）
    try {
      const shot = await cdp.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: true })
      writeFileSync(SHOT_PATH, Buffer.from(shot.data, 'base64'))
      console.log('已截图：' + SHOT_PATH)
      // 入口图标的特写
      const box = await cdp.eval(`(function(){
        var o=document.querySelector('.sao-launcher'); if(!o) return null
        var r=o.getBoundingClientRect()
        return JSON.stringify({x:Math.max(0,Math.round(r.left)-12),y:Math.max(0,Math.round(r.top)-12),
          width:Math.round(r.width)+24,height:Math.round(r.height)+24,scale:1})
      })()`)
      if (box) {
        const s2 = await cdp.send('Page.captureScreenshot', { format: 'png', clip: JSON.parse(box) })
        const orbShot = SHOT_PATH.replace(/\.png$/, '.orb.png')
        writeFileSync(orbShot, Buffer.from(s2.data, 'base64'))
        console.log('入口图标特写：' + orbShot)
      }
    } catch (e) { console.log('（截图失败：' + String((e && e.message) || e) + '）') }
    console.log('')

    // ---------- 判定 ----------
    const s = {}
    for (const kv of out.steps) { const i = kv.indexOf('='); s[kv.slice(0, i)] = kv.slice(i + 1) }
    console.log('页面实测:')
    for (const kv of out.steps) console.log('    ' + kv)
    if (out.errors.length) {
      console.log('  页面报错:')
      for (const e of out.errors) console.log('    ! ' + e)
    }
    console.log('')

    console.log('判定:')
    if (s.floatWindow === 'true') ok('float.js 建出了浮层')
    else bad('没有浮层 [data-sao-window]')
    if (s.orb === 'true') ok('圆钮存在')
    else bad('圆钮不存在')
    if (s.orbImgNatural && s.orbImgNatural !== '0x0') ok('圆钮图片已加载（' + s.orbImgNatural + '）')
    else bad('圆钮图片没加载（' + s.orbImgNatural + ' —— 图标会是空白）')
    // 核心：一次点击必须恰好开合一次，结果要"开"。
    // 有桥时，桥派发 1 次自定义事件 + 入口自己可能再 toggle 1 次 ——
    // 后者若没被压住就会"开了又关"（toggleEventsAfterClick1=1 但 display=none）。
    if (nobridge) {
      if (s.toggleEventsAfterClick1 === '0') ok('无桥时由入口自管（不发自定义事件）')
      else bad('无桥时不该发自定义事件，实际 ' + s.toggleEventsAfterClick1 + ' 次')
    } else if (s.toggleEventsAfterClick1 === '1') {
      ok('一次点击只派发一次 toggle 事件')
    } else {
      bad('一次点击派发了 ' + s.toggleEventsAfterClick1 + ' 次 toggle 事件')
    }
    if (s.afterClick1 === 'flex') ok('第 1 次点击后 display=flex')
    else bad('第 1 次点击后 display=' + s.afterClick1)
    // ---- 音频：判定走的是哪条路，然后按那条路断言"每次点击各响一声" ----
    // 自备音频路径数 <audio>.play()；合成音路径数振荡器。
    // 两条路都合法 —— 不带自备音频时必须能回退（这里曾经完全没声音）。
    const fr = (s.freqsAfterClick1 || '').split(',').map(Number).filter((n) => Number.isFinite(n))
    const chord = [880.0, 1108.7, 1318.5].filter((c) => fr.some((f) => Math.abs(f - c) < 1.5))
    const src = String(s.audioSrc || '')
    const usingCustom = !NOAUDIO && src.indexOf('/dsh-sao/link-start') !== -1
      && Number(s.audioDuration) > 0

    if (usingCustom) {
      ok('用的是自备音频：' + src)
      ok('自备音频可解码，时长 ' + Number(s.audioDuration).toFixed(2) + ' 秒')
      if (Number(s.oscillatorsAfterClick1) === 0) ok('走自备音频时不额外合成（oscillators=0）')
      else bad('走自备音频时仍在合成（oscillators=' + s.oscillatorsAfterClick1 + '）')
      for (const [label, sounds] of [
        ['第 1 次点击（开窗）', s.soundsAfterClick1],
        ['第 2 次点击（关窗）', s.soundsAfterClick2],
        ['第 3 次点击（再开）', s.soundsAfterClick3],
      ]) {
        if (Number(sounds) === 1) ok(label + '响了 1 声（自备音频）')
        else bad(label + '响了 ' + sounds + ' 声（应当恰好 1 声）')
      }
    } else {
      // 没有自备音频 → 必须回退合成音，而且**每次点击**都要出声
      if (NOAUDIO) ok('已模拟"插件不带自备音频"（/dsh-sao/link-start 一律 404）')
      else if (s.audioError && s.audioError !== 'null' && s.audioError !== 'undefined') {
        ok('自备音频不可用（' + s.audioError + '）→ 走回退路径')
      }
      if (Number(s.oscillatorsAfterClick1) > 0) ok('无自备音频，回退合成音（' + s.oscillatorsAfterClick1 + ' 个振荡器）')
      else bad('既没有自备音频也没有合成音 —— 点击不会有声音')
      if (fr.some((f) => f <= 300) && fr.some((f) => f >= 800)) ok('含上行扫频（低 ' + Math.min(...fr) + ' → 高 ' + Math.max(...fr) + ' Hz）')
      else bad('缺少上行扫频（频段 ' + fr.slice(0, 8).join(',') + '）')
      if (chord.length === 3) ok('含明亮大三和弦 A5 / C#6 / E6')
      else bad('和弦不完整，命中 ' + chord.length + '/3')
      for (const [label, osc] of [
        ['第 1 次点击（开窗）', s.oscillatorsAfterClick1],
        ['第 2 次点击（关窗）', s.oscillatorsDelta2],
        ['第 3 次点击（再开）', s.oscillatorsDelta3],
      ]) {
        if (Number(osc) > 0) ok(label + '响了（合成 ' + osc + ' 个振荡器）')
        else bad(label + '没有出声（振荡器增量 0）')
      }
    }
    if (s.afterClick2 === 'none') ok('第 2 次点击后正确关闭')
    else bad('第 2 次点击后 display=' + s.afterClick2)
    if (s.finalDisplay === 'flex') ok('第 3 次点击后重新打开')
    else bad('第 3 次点击后 display=' + s.finalDisplay)
    if (s.finalComputed && s.finalComputed.startsWith('flex/visible')) ok('真实计算样式可见：' + s.finalComputed)
    else bad('计算样式不可见：' + s.finalComputed)
    if (s.inViewport === 'true') ok('窗口在视口内：' + s.finalBox)
    else bad('窗口不在视口内：' + s.finalBox + ' · viewport ' + s.innerSize)
    if (Number(s.mainChildren) > 0) ok('卡片内容已渲染（.sao-main 子节点 ' + s.mainChildren + ' 个）')
    else bad('卡片内容是空的（.sao-main 没子节点）')
    if (s.hud === 'true') ok('顶栏 HUD 在位')
    else bad('顶栏 HUD 缺失')
    if (s.silhouette === 'true') ok('人物立绘在位')
    else bad('人物立绘缺失')
    if (out.errors.length === 0) ok('页面无 JS 报错')
    else bad('页面有 ' + out.errors.length + ' 条 JS 报错（见上）')

    console.log('')
    console.log(fail === 0 ? `全部通过 ✓（${pass} 项）` : `${fail} 项失败 ✗`)
    if (KEEP) console.log('\n（--keep：Chrome 保持运行，端口 ' + dbgPort + '）')
  } catch (err) {
    bad(String((err && err.message) || err))
    console.log('')
    console.log(`${fail} 项失败 ✗`)
  } finally {
    if (!KEEP) {
      if (cdp) cdp.close()
      try { child.kill() } catch {}
      try { spawn('taskkill', ['/PID', String(child.pid), '/T', '/F'], { stdio: 'ignore' }) } catch {}
      srv.close()
    }
  }
  process.exit(fail === 0 ? 0 : 1)
}

main()
