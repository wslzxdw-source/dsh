# -*- coding: utf-8 -*-
"""
从「浅灰白底」立绘里把人物抠出来，并额外切一张头像特写。

做法（保守、保内部细节）：
  1. 背景色按**四边内侧**中位数取（比只看四角稳）；
  2. 阈值**自适应** —— 背景可能是 #F0F0EE 这种带灰的白，写死阈值会在人物周围留一圈灰雾；
     这里从 diff 直方图里找背景峰的右边界，既不留雾也不啃人物；
  3. **只从图像外圈做 flood fill** —— 只把与边缘连通的背景判为背景，
     人物内部与背景同色的浅色区域（高光、星星、眼睛亮部）因此被保住；
  4. 边缘带按「离背景色的距离」做 Alpha 过渡并略微压暗，消掉白色描边留下的灰边；
  5. 额外输出一张头肩特写，给「悬浮窗入口圆钮 / 顶栏头像」用。

用法：
  python extract-character.py <输入图> <完整人物png> <头像png> [人物目标高度] [头像尺寸]
"""
import sys
from collections import deque
from statistics import median

import numpy as np
from PIL import Image, ImageFilter

FEATHER = 0.8


def border_background(arr):
    """取四条边内侧 10px 的中位数当背景色。"""
    h, w, _ = arr.shape
    k = 10
    pixels = np.concatenate([
        arr[:k, :].reshape(-1, 3),
        arr[-k:, :].reshape(-1, 3),
        arr[:, :k].reshape(-1, 3),
        arr[:, -k:].reshape(-1, 3),
    ])
    return np.array([median(pixels[:, i]) for i in range(3)])


def auto_tolerance(diff):
    """
    从 diff 直方图里找「背景」的右边界：背景像素 diff 集中在 0 附近，
    取累计占比 97% 的位置，夹在 [18, 60]。
    """
    vals = diff.ravel()
    small = vals[vals < 120]           # 只看低区，避免被人物内部的大值拉偏
    if small.size == 0:
        return 30.0
    hist, edges = np.histogram(small, bins=120, range=(0, 120))
    cum = np.cumsum(hist) / small.size
    idx = int(np.searchsorted(cum, 0.97))
    return float(np.clip(edges[min(idx, len(edges) - 1)], 18, 60))


def cutout(src):
    im = Image.open(src).convert('RGB')
    arr = np.asarray(im).astype(np.int16)
    h, w, _ = arr.shape
    bg = border_background(arr)
    diff = np.abs(arr - bg.reshape(1, 1, 3)).max(axis=2)
    tol = auto_tolerance(diff)
    print(f'图像 {w}x{h}')
    print(f'背景色 ≈ #{int(bg[0]):02X}{int(bg[1]):02X}{int(bg[2]):02X} · 自适应阈值 {tol:.0f}')

    solid = diff > tol
    maybe_bg = ~solid

    # 只从外圈 flood fill：人物内部与背景同色的浅色区域会被保住
    outside = np.zeros((h, w), dtype=bool)
    q = deque()
    for x in range(w):
        for y in (0, h - 1):
            if maybe_bg[y, x] and not outside[y, x]:
                outside[y, x] = True
                q.append((y, x))
    for y in range(h):
        for x in (0, w - 1):
            if maybe_bg[y, x] and not outside[y, x]:
                outside[y, x] = True
                q.append((y, x))
    while q:
        y, x = q.popleft()
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            ny, nx = y + dy, x + dx
            if 0 <= ny < h and 0 <= nx < w and maybe_bg[ny, nx] and not outside[ny, nx]:
                outside[ny, nx] = True
                q.append((ny, nx))
    print(f'判定为背景（与边缘连通）占比 {outside.mean() * 100:.1f}%')

    # 边缘带按「离背景色多远」做 Alpha 过渡，并略微压暗以消掉白描边灰边
    alpha = np.where(outside, 0.0, 1.0)
    band = (~outside) & maybe_bg
    t = np.clip(diff.astype(np.float32) / max(tol, 1.0), 0.0, 1.0)
    alpha[band] = np.clip(t[band] * 0.85, 0.0, 1.0)

    a_img = Image.fromarray((alpha * 255).astype(np.uint8), 'L')
    a_img = a_img.filter(ImageFilter.MedianFilter(size=3))
    a_img = a_img.filter(ImageFilter.GaussianBlur(FEATHER))
    alpha = np.asarray(a_img).astype(np.float32) / 255.0

    rgba = np.dstack([np.asarray(im).astype(np.uint8), (np.clip(alpha, 0, 1) * 255).astype(np.uint8)])
    full = Image.fromarray(rgba, 'RGBA')

    # 裁掉四周全透明区域（留 2px 余量）
    bbox = full.getchannel('A').point(lambda v: 255 if v > 10 else 0).getbbox()
    if bbox:
        bbox = (max(0, bbox[0] - 2), max(0, bbox[1] - 2),
                min(w, bbox[2] + 2), min(h, bbox[3] + 2))
        full = full.crop(bbox)
    a = np.asarray(full.getchannel('A'))
    print(f'完整人物 {full.size[0]}x{full.size[1]} · 透明占比 {(a <= 10).mean() * 100:.1f}%')
    return full


def head_shot(full, size, side_f=0.82, center_y_f=0.36, head_range_f=0.32):
    """
    从立绘里切一张头像特写（行为完全确定，不用启发式）。

    呆毛那根细线会把"头顶"的自动检测拉到画面最上沿，所以纵向位置改成
    **整图高度的固定比例**（对同一张立绘是确定值），横向则在"头部范围"内取包围盒中心：

      head_range_f —— 头部纵向范围 = 整图高度 × 该比例，从最顶往下量（默认 0.32）
      center_y_f   —— 正方形中心落在整图高度的哪个位置（默认 0.36）
      side_f       —— 正方形边长 = 整图高度 × 该比例（默认 0.82：要装下鲸鱼耳）

    这张立绘（缩放后 729x760）量出来的结果：脸宽约 x[130,470]、y[76,266]，
    鲸鱼耳最宽到 x[81,535]，脸中心大约 (308, 180)。
    """
    arr = np.asarray(full)
    alpha = arr[:, :, 3]
    h, w = alpha.shape
    ys, xs = np.nonzero(alpha > 120)
    if ys.size == 0:
        ys = np.array([0]); xs = np.array([0])
    top = int(ys.min())

    head_top = top
    head_bottom = int(top + h * head_range_f)
    _, head_xs = np.nonzero(alpha[head_top:head_bottom + 1] > 120)
    hx0 = int(head_xs.min()) if head_xs.size else 0
    hx1 = int(head_xs.max()) if head_xs.size else w - 1
    cx = (hx0 + hx1) // 2
    cy = int(h * center_y_f)

    side = max(32, min(int(round(h * side_f)), w, h))
    left = int(np.clip(cx - side // 2, 0, max(0, w - side)))
    upper = int(np.clip(cy - side // 2, 0, max(0, h - side)))

    print(f'头部 y[{head_top},{head_bottom}] x[{hx0},{hx1}] 宽 {hx1 - hx0 + 1} · 中心 x={cx}')
    print(f'→ 裁切 x[{left},{left + side}] y[{upper},{upper + side}] 边长 {side}')
    if hx1 - hx0 + 1 > side:
        print(f'⚠ 头部宽 {hx1 - hx0 + 1} 超过边长 {side}，会被裁掉两侧 —— 调大 side_f')
    box = full.crop((left, upper, left + side, upper + side))
    return box.resize((size, size), Image.LANCZOS)


def main():
    src = sys.argv[1]
    dst_full = sys.argv[2]
    dst_head = sys.argv[3] if len(sys.argv) > 3 else None
    target_h = int(sys.argv[4]) if len(sys.argv) > 4 else 760
    head_size = int(sys.argv[5]) if len(sys.argv) > 5 else 256

    full = cutout(src)

    # 先缩放到目标高度，再切头像 ——
    # 否则头像是在源图分辨率上按比例切的，和"量出来的比例"不是同一个坐标系（踩过）。
    if full.size[1] > target_h:
        ratio = target_h / full.size[1]
        full = full.resize((max(1, round(full.size[0] * ratio)), target_h), Image.LANCZOS)

    if dst_head:
        head = head_shot(full, head_size)
        head.save(dst_head, 'PNG', optimize=True)
        a = np.asarray(head.getchannel('A'))
        print(f'头像 {head.size[0]}x{head.size[1]} · 透明占比 {(a <= 10).mean() * 100:.1f}%')
        print(f'已写出 {dst_head}')

    full.save(dst_full, 'PNG', optimize=True)
    print(f'已写出 {dst_full}：{full.size[0]}x{full.size[1]}')


if __name__ == '__main__':
    main()
