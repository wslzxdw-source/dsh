// ---------------------------------------------------------------------------
// dsh-sao-window —— 宿主半侧离线自检
//
// 用假的 cordis 上下文加载 lib/index.js，检查：
//   ① 服务注入（webServer / credentials）
//   ② 4 条 HTTP 路由都注册了
//   ③ index 注入行的内容：必须加载 /dsh-sao/float.js 与 /dsh-sao/bridge.js，
//      且注入脚本本身语法合法（会被真当成页面脚本执行）
//   ④ 信任栅栏真的生效（跨站 / 伪造 Origin → 403）
//
// 运行：node scripts/host-smoke.mjs lib/index.js
// ---------------------------------------------------------------------------

import { pathToFileURL } from 'node:url'
import fs from 'node:fs'

const target = process.argv[2] || 'lib/index.js'
const mod = await import(pathToFileURL(target).href)
const plugin = mod.default

let failures = 0
const ok = (s) => console.log('  \u2713 ' + s)
const bad = (s, err) => { failures += 1; console.log('  \u2717 ' + s + (err ? ' — ' + String((err && err.message) || err) : '')) }

console.log('宿主半侧自检：' + target)
console.log('')
console.log('name:  ' + plugin.name)
console.log('apply: ' + typeof plugin.apply)

const routes = []
const injects = []
const tapTransforms = []

const ctxStub = {
  credentials: { resolve: async () => null },
  get: () => null,
  effect(fn) { fn(); return () => {} },
  webServer: {
    port: 3080,
    register(route) { routes.push(route); return () => {} },
    // 唯一的注入通道：tapIndex 改写 index.html
    tapIndex(transform) { tapTransforms.push(transform); return () => {} },
  },
}
const root = {
  effect(fn) { fn(); return () => {} },
  on() { return () => {} },
  inject(deps, cb) { injects.push(deps); cb(ctxStub) },
}

try {
  plugin.apply(root)
  ok('apply() 执行成功')
} catch (err) {
  bad('apply() 抛错', err)
}

console.log('')
console.log('服务注入: ' + JSON.stringify(injects))
if (!injects.some((d) => d.includes('webServer'))) bad('没有注入 webServer')
else ok('注入 webServer')

console.log('')
console.log('路由（' + routes.length + ' 条）:')
for (const r of routes) console.log('  ' + r.kind.padEnd(6) + r.path)
for (const want of ['/dsh-sao/balance.json', '/dsh-sao/character.png', '/dsh-sao/head.png',
  '/dsh-sao/float.js', '/dsh-sao/bridge.js', '/dsh-sao/link-start']) {
  if (!routes.some((r) => r.path === want)) bad('缺少路由 ' + want)
  else ok('路由 ' + want)
}
// 独立化：路由里不该再有 whale 相关路径
if (routes.some((r) => r.path.includes('whale'))) bad('还挂着 whale 相关路由')
else ok('无 whale 相关路由（完全独立）')

console.log('')
console.log('页面脚本注入（tapIndex 单通道）:')
if (tapTransforms.length === 0) bad('apply() 没有挂 tapIndex（页面脚本不会被注入）')
else if (tapTransforms.length > 1) bad('挂了 ' + tapTransforms.length + ' 个 tapIndex —— 会导致客户端脚本执行多次')
else {
  ok('挂了 1 个 tapIndex（单通道，避免脚本被执行两次）')
  const html = '<html><body><div id="root"></div></body></html>'
  const out = tapTransforms[0](html)
  if (out.indexOf('/dsh-sao/float.js') === -1) bad('注入后 HTML 里没有 float.js')
  else ok('注入后 HTML 含 <script src="/dsh-sao/float.js">')
  if (out.indexOf('</body>') !== -1 && out.indexOf('/dsh-sao/float.js') < out.indexOf('</body>')) {
    ok('注入位置在 </body> 之前')
  } else bad('注入位置不对（应在 </body> 之前）')
  // 幂等：已注入过的 HTML 再走一遍不应重复插入
  const again = tapTransforms[0](out)
  const hits = again.split('/dsh-sao/float.js').length - 1
  if (hits !== 1) bad('tapIndex 不幂等（float.js 出现 ' + hits + ' 次）')
  else ok('tapIndex 幂等（重复调用不会重复注入）')
}

// 信任栅栏
console.log('')
console.log('信任栅栏:')
const balance = routes.find((r) => r.path === '/dsh-sao/balance.json')
if (!balance) {
  bad('没有 balance.json 路由，跳过栅栏检查')
} else {
  const cases = [
    { label: '正常回环请求', headers: { host: '127.0.0.1:3080' }, expect: '200' },
    { label: '跨站标记', headers: { host: '127.0.0.1:3080', 'sec-fetch-site': 'cross-site' }, expect: '403' },
    { label: '伪造 Origin', headers: { host: '127.0.0.1:3080', origin: 'https://evil.example' }, expect: '403' },
    { label: '非回环 Host', headers: { host: 'evil.example' }, expect: '403' },
    { label: '缺 Host', headers: {}, expect: '403' },
  ]
  for (const c of cases) {
    let code = null
    const res = {
      writeHead(status) { code = status },
      end() {},
    }
    const ctx = { credentials: { resolve: async () => null }, get: () => null }
    try {
      // 栅栏通过时会接着走真实 handler；没有凭据/账号服务，最终也是 200 + ok:false
      await balance.handler({ method: 'GET', url: '/dsh-sao/balance.json', headers: c.headers }, res)
    } catch (err) {
      // 真实 handler 在假 ctx 下可能抛错，这里只关心状态码有没有被栅栏写过
    }
    const got = code === null ? '(handler 自身异常)' : String(code)
    if (got !== c.expect) bad(c.label + ' 期望 ' + c.expect + '，实际 ' + got)
    else ok(c.label + ' → ' + got)
  }
}

console.log('')
console.log(failures === 0 ? '全部通过 \u2713' : failures + ' 项失败 \u2717')
process.exit(failures === 0 ? 0 : 1)
