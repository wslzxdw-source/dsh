# -*- coding: utf-8 -*-
"""
从 MP4 里无损提取音频轨，重封装成浏览器可直接播放的 .m4a（AAC-in-MP4）。

为什么自己写而不是用 ffmpeg：
  · 这台机器上没有 ffmpeg，DSH 自带的 Electron 里也没有；
  · Python 侧没有 soundfile / pydub / av，装不了（离线）；
  · Python 标准库的 `wave` 只能读写 WAV，读不了 MP4/AAC。
  · 而 MP4 的音频轨本来就是 AAC 采样帧，**只要把采样表重算一遍、
    改写 chunk offset，就能原样搬进一个新的 MP4 容器** —— 不需要任何编解码器，
    音质完全无损，产物浏览器原生支持（.m4a）。

只做音频轨，视频轨整个丢掉。

用法：
  python extract-mp4-audio.py <输入.mp4> <输出.m4a>
"""
import struct
import sys
from pathlib import Path

CONTAINER = {
    b'moov', b'trak', b'mdia', b'minf', b'stbl', b'edts', b'dinf', b'udta',
    b'meta', b'ilst', b'stsd',
}


def parse_boxes(data, start, end):
    """把 [start,end) 里的 box 平铺解析成 (type, box_start, payload_start, box_end)。"""
    out = []
    i = start
    while i + 8 <= end:
        size = struct.unpack('>I', data[i:i + 4])[0]
        btype = data[i + 4:i + 8]
        header = 8
        if size == 1:
            if i + 16 > end:
                break
            size = struct.unpack('>Q', data[i + 8:i + 16])[0]
            header = 16
        elif size == 0:
            size = end - i
        if size < header or i + size > end:
            break
        out.append((btype, i, i + header, i + size))
        i += size
    return out


def find_first(data, boxes, path):
    """按路径找第一个 box，返回同样的四元组；找不到返回 None。"""
    cur = boxes
    hit = None
    for name in path:
        hit = None
        for b in cur:
            if b[0] == name:
                hit = b
                break
        if hit is None:
            return None
        # 继续往里找；stsd 内部先有 8 字节的版本/条目数字段
        nxt = hit[2]
        if name == b'stsd':
            nxt += 8
        cur = parse_boxes(data, nxt, hit[3])
    return hit


def read_table(data, box, entry_size):
    """读 stsz / stco / stsc / stts 这类"版本+flags(4) + count(4) + 定长条目"的表。"""
    if box is None:
        return []
    payload, end = box[2], box[3]
    count = struct.unpack('>I', data[payload + 4:payload + 8])[0]
    p = payload + 8
    rows = []
    for _ in range(count):
        if p + entry_size > end:
            break
        rows.append(data[p:p + entry_size])
        p += entry_size
    return rows


def bytes_to_chunks(stsc_rows, total_chunks):
    """stsc → 每个 chunk 的样本数（Python 的 range 也是含头不含尾，正好对上）。"""
    if not stsc_rows:
        return []
    entries = []
    for r in stsc_rows:
        first = struct.unpack('>I', r[0:4])[0]
        per = struct.unpack('>I', r[4:8])[0]
        entries.append((first, per))
    out = []
    for idx in range(len(entries)):
        start = entries[idx][0]
        end = entries[idx + 1][0] if idx + 1 < len(entries) else total_chunks + 1
        per = entries[idx][1]
        for _ in range(start, end):
            out.append(per)
    return out


def box(btype, payload):
    return struct.pack('>I', len(payload) + 8) + btype + payload


def build_stco(offsets):
    payload = b'\x00\x00\x00\x00' + struct.pack('>I', len(offsets))
    for o in offsets:
        payload += struct.pack('>I', o)
    return box(b'stco', payload)


def main():
    argv = [a for a in sys.argv[1:] if not a.startswith('--')]
    keep_metadata = '--keep-metadata' in sys.argv
    if len(argv) < 2:
        raise SystemExit('用法: python extract-mp4-audio.py <输入.mp4> <输出.m4a> [--keep-metadata]')
    src = Path(argv[0])
    dst = Path(argv[1])
    data = src.read_bytes()
    print('输入 %s（%d 字节）' % (src, len(data)))

    top = parse_boxes(data, 0, len(data))
    tops = {b[0]: b for b in top}
    for b in top:
        print('  box %s size=%d' % (b[0].decode('latin1', 'replace'), b[3] - b[1]))

    moov = tops.get(b'moov')
    if moov is None:
        raise SystemExit('没有 moov box，无法解析')
    moov_payload, moov_end = moov[2], moov[3]
    moov_children = parse_boxes(data, moov_payload, moov_end)

    # 找音频轨（hdlr == 'soun'）
    audio_trak = None
    for b in moov_children:
        if b[0] != b'trak':
            continue
        hdlr = find_first(data, parse_boxes(data, b[2], b[3]), [b'mdia', b'hdlr'])
        if hdlr is None:
            continue
        kind = data[hdlr[2] + 8:hdlr[2] + 12]
        print('  轨道 handler = %s' % kind.decode('latin1', 'replace'))
        if kind == b'soun':
            audio_trak = b
            break
    if audio_trak is None:
        raise SystemExit('没找到音频轨')

    trak_children = parse_boxes(data, audio_trak[2], audio_trak[3])
    mdia = [c for c in trak_children if c[0] == b'mdia'][0]
    mdia_children = parse_boxes(data, mdia[2], mdia[3])
    minf = [c for c in mdia_children if c[0] == b'minf'][0]
    minf_children = parse_boxes(data, minf[2], minf[3])
    stbl = [c for c in minf_children if c[0] == b'stbl'][0]
    stbl_children = parse_boxes(data, stbl[2], stbl[3])
    print('  音频轨 stbl 里的表: ' + ' '.join(
        '%s(%d)' % (c[0].decode('latin1', 'replace'), c[3] - c[1]) for c in stbl_children))

    def stbl_box(name):
        for c in stbl_children:
            if c[0] == name:
                return c
        return None

    # ---- 采样表 ----
    stsz_box = stbl_box(b'stsz')
    if stsz_box is None:
        raise SystemExit('音频轨没有 stsz')
    # stsz：版本+flags(4) · sample_size(4) · count(4) · [entry(4)]*count
    uniform = struct.unpack('>I', data[stsz_box[2] + 4:stsz_box[2] + 8])[0]
    declared = struct.unpack('>I', data[stsz_box[2] + 8:stsz_box[2] + 12])[0]
    print('  stsz: sample_size=%d count=%d' % (uniform, declared))
    if uniform:
        sample_sizes = [uniform] * declared
    else:
        sample_sizes = [
            struct.unpack('>I', data[stsz_box[2] + 12 + i * 4:stsz_box[2] + 16 + i * 4])[0]
            for i in range(declared)
        ]

    stco_box = stbl_box(b'stco')
    if stco_box is None:
        raise SystemExit('音频轨没有 stco')
    chunk_count = struct.unpack('>I', data[stco_box[2] + 4:stco_box[2] + 8])[0]
    chunk_offsets = [
        struct.unpack('>I', data[stco_box[2] + 8 + i * 4:stco_box[2] + 12 + i * 4])[0]
        for i in range(chunk_count)
    ]

    stsc_box = stbl_box(b'stsc')
    if stsc_box is None:
        raise SystemExit('音频轨没有 stsc')
    stsc_count = struct.unpack('>I', data[stsc_box[2] + 4:stsc_box[2] + 8])[0]
    stsc_rows = [
        data[stsc_box[2] + 8 + i * 12:stsc_box[2] + 20 + i * 12]
        for i in range(stsc_count)
    ]
    print('  stco: %d 个 chunk · stsc: %d 条' % (chunk_count, stsc_count))
    per_chunk = bytes_to_chunks(stsc_rows, len(chunk_offsets))
    total = sum(per_chunk)
    print('  音频：%d 个 chunk · %d 个样本 · stsz 里 %d 条'
          % (len(chunk_offsets), total, len(sample_sizes)))
    if total != len(sample_sizes):
        raise SystemExit('chunk 样本数(%d) 与 stsz 条数(%d) 不一致，拒绝继续' % (total, len(sample_sizes)))

    # ---- 按 chunk 收集字节，保持 chunk 边界 ----
    # 同一个 chunk 里的样本在文件里是连续排列的，所以整块读出来正好。
    mdat_payload = []
    chunk_sizes = []
    cursor = 0
    for ci, off in enumerate(chunk_offsets):
        n = per_chunk[ci]
        size = sum(sample_sizes[cursor:cursor + n])
        mdat_payload.append(data[off:off + size])
        chunk_sizes.append(size)
        cursor += n
    if cursor != len(sample_sizes):
        raise SystemExit('样本数对不上')
    audio_bytes = b''.join(mdat_payload)
    print('  抽取音频字节 %d 字节（%d 个 chunk）' % (len(audio_bytes), len(chunk_sizes)))

    # ---- 组装新文件 ----
    # ftyp
    ftyp = box(b'ftyp', b'M4A ' + struct.pack('>I', 512) + b'M4A ' + b'mp42' + b'isom')
    # mdat
    mdat = box(b'mdat', audio_bytes)

    # stco 重算：新 mdat 的 payload 起点 = len(ftyp) + 8
    data_start = len(ftyp) + 8
    new_offsets = []
    run = 0
    for size in chunk_sizes:
        new_offsets.append(data_start + run)
        run += size

    # 新的 stbl：stsd/stts/stsc/stsz 原样搬，stco 换成重算的
    # 注意 stco→co64：大文件才需要，这个文件小，保持 stco
    new_children = []
    for c in stbl_children:
        if c[0] == b'stco':
            new_children.append(build_stco(new_offsets))
        elif c[0] == b'co64':
            continue
        else:
            new_children.append(data[c[1]:c[3]])
    new_stbl = box(b'stbl', b''.join(new_children))

    new_minf = box(b'minf', b''.join(
        data[c[1]:c[3]] if c[0] != b'stbl' else new_stbl
        for c in minf_children))

    new_mdia = box(b'mdia', b''.join(
        data[c[1]:c[3]] if c[0] != b'minf' else new_minf
        for c in mdia_children))

    # trak 里除了 mdia 还有 tkhd / edts 等，原样搬
    new_trak = box(b'trak', b''.join(
        data[c[1]:c[3]] if c[0] != b'mdia' else new_mdia
        for c in trak_children))

    # moov：mvhd 原样（时长仍是原视频的，无伤大雅）+ 新 trak；丢掉视频轨。
    #
    # ⚠ **默认丢弃 udta / meta / ilst（元数据）**。这不是洁癖：
    #   剪辑软件会在里面写进"属于你自己的"东西。实测一份剪映导出的 mp4 里就有：
    #     videoId                = 项目唯一 ID   ← 等于把项目标识打进了插件
    #     product / source_type  = lv / douyin_beauty_me（用了剪映美颜）
    #     is_use_vc_sing_clone   = 1（用过声音克隆）
    #     os                     = windows
    #   这些都跟音频播放毫无关系。确实想保留就加 --keep-metadata。
    moov_parts = []
    for c in moov_children:
        if c[0] == b'trak':
            continue
        if c[0] == b'mvhd':
            moov_parts.append(data[c[1]:c[3]])
        elif c[0] in (b'udta', b'meta', b'iods'):
            if keep_metadata:
                moov_parts.append(data[c[1]:c[3]])
            else:
                print('  已丢弃元数据 box: %s（%d 字节）'
                      % (c[0].decode('latin1', 'replace'), c[3] - c[1]))
    moov_parts.append(new_trak)
    new_moov = box(b'moov', b''.join(moov_parts))

    out = ftyp + mdat + new_moov
    dst.write_bytes(out)
    print('已写出 %s（%d 字节）' % (dst, len(out)))
    print('  chunk 数 %d · 首个样本偏移 %d' % (len(new_offsets), new_offsets[0] if new_offsets else -1))


if __name__ == '__main__':
    main()
