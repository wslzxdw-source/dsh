// ---------------------------------------------------------------------------
// dsh-sao-window —— 运行期路由自检
//
// 向正在运行的 DSH 逐条请求本插件的路由，判断宿主半侧是否已经加载。
// 用法：
//   node scripts/probe-routes.mjs                 # 默认 http://127.0.0.1:19387
//   node scripts/probe-routes.mjs http://127.0.0.1:3080
// 环境变量：DSH_WEB_URL
//
// 说明：DSH 有浏览器信任栅栏，裸请求返回 401/403 属于「路由存在但需要会话」，
// 只有 404 才说明这条路由没注册（宿主半侧没加载）。
// ---------------------------------------------------------------------------

const base = process.argv[2] || process.env.DSH_WEB_URL || 'http://127.0.0.1:19387'

const ROUTES = [
  { path: '/dsh-sao/balance.json', expect: 'json' },
  { path: '/dsh-sao/character.png', expect: 'image' },
  { path: '/dsh-sao/bridge.js', expect: 'js' },
  { path: '/dsh-sao/window.js', expect: 'js' },
]

let notLoaded = 0

console.log('探测目标：' + base)
console.log('')

for (const route of ROUTES) {
  const url = base + route.path
  let line
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(8000) })
    const text = res.status === 200 ? (await res.text()).slice(0, 160) : ''
    const kind = res.headers.get('content-type') || ''
    if (res.status === 404) {
      notLoaded += 1
      line = '404  未注册（宿主半侧没加载）'
    } else if (res.status === 401 || res.status === 403) {
      line = res.status + '  路由已注册，被浏览器信任栅栏拦下（正常，浏览器里带会话访问才是 200）'
    } else if (res.status === 200) {
      line = '200  ' + kind + (route.expect === 'json' ? '  ' + text : '')
    } else {
      line = res.status + '  ' + kind
    }
  } catch (err) {
    line = '请求失败：' + String((err && err.message) || err)
    notLoaded += 1
  }
  console.log('  ' + route.path.padEnd(26) + ' ' + line)
}

console.log('')
if (notLoaded > 0) {
  console.log('结论：宿主半侧**尚未加载**（' + notLoaded + ' 条路由没响应）。')
  console.log('      桌面端读的是 desktop profile —— 请在桌面客户端里确认已安装，然后**重开一次客户端**。')
  process.exit(1)
}
console.log('结论：4 条路由都已存在 → 宿主半侧已加载 ✓')
console.log('      接下来看客户端半侧：悬浮窗是否出现（点右下角小鲸鱼），')
console.log('      以及「设置 → 插件 → 插件列表」里 dsh-sao-window 是否 active。')
