// ---------------------------------------------------------------------------
// dsh-sao-window —— 悬浮窗页面脚本离线验证
//
// 在一个最小 DOM 沙箱里真实执行 lib/float.js，然后：
//   ① 检查它建出的浮层结构（class / 文案 / 立绘 src）
//   ② 模拟点小鲸鱼派发 dsh-sao:toggle，检查开合
//   ③ 切到「模型」「登出」两个 tab，检查各自面板
//   ④ 走一遍余额渲染（mock fetch 返回余额）
//
// 运行：node scripts/verify-float.mjs
// ---------------------------------------------------------------------------

import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const HERE = path.dirname(fileURLToPath(import.meta.url))
const FLOAT = path.join(HERE, '..', 'lib', 'float.js')

let failures = 0
const ok = (s) => console.log('  \u2713 ' + s)
const bad = (s, err) => { failures += 1; console.log('  \u2717 ' + s + (err ? ' — ' + String((err && err.stack) || err) : '')) }

// ------------------------------ 最小 DOM ------------------------------
function makeDom() {
  const all = []

  class Node {
    constructor(tag) {
      this.tagName = String(tag || '').toUpperCase()
      this.children = []
      this.parentNode = null
      this.style = { cssText: '', setProperty() {} }
      this.dataset = {}
      this.attributes = {}
      this._text = ''
      this._listeners = {}
      this.className = ''
      this.disabled = false
      this.src = ''
      this.alt = ''
      this.draggable = false
      this.title = ''
      this.type = ''
      this.offsetWidth = 404
      this.offsetHeight = 300
      this.currentSrc = ''
      all.push(this)
    }
    set textContent(v) { this._text = String(v); this.children = [] }
    // 真实 DOM 里 appendChild 会把节点挂进树 —— 这里也登记一条「已挂载」关系，
    // 否则 parentNode 永远为 null，破坏性检查（清理是否彻底）就失去意义。
    appendChildTo(node) { this.children.push(node); node.parentNode = this; return node }
    get textContent() {
      let out = this._text
      for (const c of this.children) out += c.textContent
      return out
    }
    appendChild(child) { child.parentNode = this; child.removed = false; this.children.push(child); return child }
    removeChild(child) {
      const i = this.children.indexOf(child)
      if (i >= 0) this.children.splice(i, 1)
      child.parentNode = null
      // 真实 DOM 里被移除的节点（连同子树）不再 document.contains。
      // 用 removed 标记它，让「清理是否彻底」的断言有意义。
      const mark = (n) => { n.removed = true; for (const c of n.children) mark(c) }
      mark(child)
      return child
    }
    setAttribute(k, v) { this.attributes[k] = String(v); if (k === 'class') this.className = String(v) }
    getAttribute(k) { return k in this.attributes ? this.attributes[k] : null }
    removeAttribute(k) { delete this.attributes[k] }
    set dataset(v) { this._dataset = v }
    get dataset() {
      if (!this._dataset) this._dataset = {}
      // 真实 DOM 里 dataset.pluginCss 会映射成 data-plugin-css 属性
      if (!this._datasetProxy) {
        const self = this
        this._datasetProxy = new Proxy(this._dataset, {
          set(t, key, value) {
            t[key] = String(value)
            const attr = 'data-' + String(key).replace(/[A-Z]/g, (m) => '-' + m.toLowerCase())
            self.attributes[attr] = String(value)
            return true
          },
        })
      }
      return this._datasetProxy
    }
    addEventListener(name, fn) { (this._listeners[name] = this._listeners[name] || []).push(fn) }
    removeEventListener(name, fn) {
      const list = this._listeners[name] || []
      const i = list.indexOf(fn)
      if (i >= 0) list.splice(i, 1)
    }
    dispatch(name, event) { for (const fn of this._listeners[name] || []) fn(event || {}) }
    setPointerCapture() {}
    // 尊重 inline 的 left/top/right/bottom —— 否则"窗口跑到视口外"这类 bug
    // 在沙箱里永远测不出来（固定返回值等于假装位置永远正确）。
    getBoundingClientRect() {
      const px = (v) => (typeof v === 'string' && v.endsWith('px') ? parseFloat(v) : null)
      const vw = 1440, vh = 900
      const width = this.offsetWidth || 404
      const height = this.offsetHeight || 300
      let left = px(this.style.left)
      let top = px(this.style.top)
      if (left === null) {
        const right = px(this.style.right)
        left = right === null ? vw - width - 24 : vw - right - width
      }
      if (top === null) {
        const bottom = px(this.style.bottom)
        top = bottom === null ? vh - height - 24 : vh - bottom - height
      }
      return {
        left, top, width, height,
        right: left + width, bottom: top + height,
        x: left, y: top,
      }
    }
    closest(sel) {
      const cls = sel.replace(/^\./, '')
      let node = this
      while (node) {
        if (node.className && String(node.className).split(/\s+/).includes(cls)) return node
        if (sel === 'button' && node.tagName === 'BUTTON') return node
        node = node.parentNode
      }
      return null
    }
    querySelector(sel) {
      const match = (n) => {
        if (sel.startsWith('[') && sel.endsWith(']')) {
          const k = sel.slice(1, -1).split('=')[0]
          return k in n.attributes
        }
        if (sel.startsWith('.')) return String(n.className || '').split(/\s+/).includes(sel.slice(1))
        return n.tagName === sel.toUpperCase()
      }
      const walk = (n) => {
        for (const c of n.children) {
          if (match(c)) return c
          const deep = walk(c)
          if (deep) return deep
        }
        return null
      }
      return walk(this)
    }
    querySelectorAll(sel) {
      const out = []
      const match = (n) => {
        if (sel.startsWith('.')) return String(n.className || '').split(/\s+/).includes(sel.slice(1))
        if (sel === 'button') return n.tagName === 'BUTTON'
        return n.tagName === sel.toUpperCase()
      }
      const walk = (n) => { for (const c of n.children) { if (match(c)) out.push(c); walk(c) } }
      walk(this)
      return out
    }
    get isConnected() { return true }
  }

  const document = {
    readyState: 'complete',
    documentElement: null,
    head: null,
    body: null,
    createElement: (tag) => new Node(tag),
    // 人物面板的联结线用 SVG 画：Node 侧需要 createElementNS
    createElementNS: (_ns, tag) => new Node(tag),
    createTextNode: (text) => {
      const n = new Node('#text')
      n._text = String(text)
      return n
    },
    addEventListener() {},
    querySelector: () => null, // 让 stage() 自己创建标记节点
    get images() { return all.filter((n) => n.tagName === 'IMG') },
  }
  const html = new Node('html')
  const head = new Node('head')
  const body = new Node('body')
  html.appendChild(head)
  html.appendChild(body)
  document.documentElement = html
  document.head = head
  document.body = body
  document.querySelector = (sel) => html.querySelector(sel)

  const listeners = {}
  const docListeners = {}
  document.addEventListener = (name, fn) => { (docListeners[name] = docListeners[name] || []).push(fn) }
  document.removeEventListener = () => {}
  const window = {
    innerWidth: 1440,
    innerHeight: 900,
    addEventListener: (n, fn) => { (listeners[n] = listeners[n] || []).push(fn) },
    removeEventListener: (n, fn) => {
      const list = listeners[n] || []
      const i = list.indexOf(fn)
      if (i >= 0) list.splice(i, 1)
    },
    dispatchEvent: (ev) => { for (const fn of listeners[ev.type] || []) fn(ev) },
  }

  return { document, window, Node, all, listeners }
}

// ------------------------------ 渲染输出 ------------------------------
function outline(node, depth, out) {
  const pad = '  '.repeat(depth)
  if (!node || !node.tagName) return
  if (node.tagName === '#TEXT') { if (node._text) out.push(pad + '# ' + node._text); return }
  const cls = node.className ? ' class="' + node.className + '"' : ''
  const src = node.src ? ' src="' + node.src + '"' : ''
  const dis = node.disabled ? ' disabled' : ''
  out.push(pad + '<' + node.tagName.toLowerCase() + cls + src + dis + '>')
  if (node._text) out.push(pad + '  # ' + node._text)
  for (const c of node.children) outline(c, depth + 1, out)
}

// ------------------------------ 执行 ------------------------------
console.log('dsh-sao-window · float.js 离线验证')
console.log('目标：' + FLOAT)

const source = fs.readFileSync(FLOAT, 'utf8')
const dom = makeDom()
// 把注入进来的 CSS 抓出来，便于直接断言样式规则本身
let cssText = ''
const origAppend = dom.document.head.appendChild.bind(dom.document.head)
dom.document.head.appendChild = (node) => {
  if (node && node.tagName === 'STYLE' && typeof node.textContent === 'string') cssText += node.textContent
  return origAppend(node)
}

// mock fetch：返回余额（余额可切换，用来验证血条分档）
const fetched = []
let mockBalance = { ok: true, totalBalance: 12.5, currency: 'CNY', source: 'account' }
globalThis.fetch = async (url) => {
  fetched.push(String(url))
  return { json: async () => mockBalance }
}
globalThis.CustomEvent = class CustomEvent {
  constructor(type, init) { this.type = type; this.detail = init && init.detail }
}
// WebAudio 桩：记录每次合成的振荡器型号/频率，用来验证「叮」确实响且各事件不同。
//
// ⚠ 每次 new AudioContext() 都换一个**新的记录数组**，而不是共用一个。
//   原因：本文件后面会再跑一遍 float.js（模拟"两个注入通道各载入一次"），
//   那一遍里也有一条 `sounds.length = 0`。共用一个数组时，第二遍会把第一遍
//   的数字清掉，于是先前的断言读到 0 —— 白白排查了半天桩的问题。
//   真实浏览器里本来就该是"每个 AudioContext 自己的振荡器"，
//   所以这样也更贴近真实语义。
const sounds = []
globalThis.AudioContext = class AudioContext {
  constructor() {
    this.state = 'running'
    this.currentTime = 0
    this.destination = {}
    // 新实例 → 新的记录数组；sounds 本身作为"当前实例的记录"被读
    this._rec = []
    globalThis.__saoSounds = this._rec
  }
  resume() {}
  createOscillator() {
    const rec = { type: '', f0: null }
    this._rec.push(rec)
    return {
      get type() { return rec.type }, set type(v) { rec.type = v },
      detune: { value: 0 },
      frequency: {
        setValueAtTime(v) { rec.f0 = v },
        exponentialRampToValueAtTime() {},
      },
      connect() {}, start() {}, stop() {},
    }
  }
  createGain() {
    return {
      gain: { value: 1, setValueAtTime() {}, exponentialRampToValueAtTime() {} },
      connect() {},
    }
  }
}
globalThis.document = dom.document
globalThis.window = dom.window
globalThis.window.AudioContext = globalThis.AudioContext
globalThis.setTimeout = setTimeout
globalThis.clearTimeout = clearTimeout
globalThis.setInterval = () => 1
globalThis.clearInterval = () => {}

let threw = null
try {
  new Function('window', 'document', 'fetch', 'setTimeout', 'clearTimeout', 'setInterval', 'clearInterval', 'CustomEvent', source)(
    dom.window, dom.document, globalThis.fetch, setTimeout, clearTimeout,
    () => 1, () => {}, globalThis.CustomEvent,
  )
} catch (err) { threw = err }

if (threw) bad('float.js 执行抛错', threw)
else ok('float.js 执行成功（无抛错）')

// 找浮层
const win = dom.document.querySelector('[data-sao-window]')
if (!win) bad('没有建出 [data-sao-window] 浮层')
else ok('建出浮层 [data-sao-window]')

if (win) {
  const out = []
  outline(win, 0, out)
  console.log('')
  console.log(out.slice(0, 30).join('\n'))
  console.log('  …（共 ' + out.length + ' 行）')
  console.log('')

  const html = out.join('\n')
  for (const t of ['sao-card', 'sao-rail', 'sao-orb', 'sao-notch',
    'sao-hp-track', 'sao-hp-fill', 'sao-portrait', 'sao-links',
    'sao-silhouette', '/dsh-sao/character.png', 'sao-foot', 'sao-title']) {
    if (html.indexOf(t) === -1) bad('结构里缺少「' + t + '」')
    else ok('结构包含 ' + t)
  }
  // 顶栏 HUD：只应有「头像 + 血条」，余额相关一律不在顶栏
  for (const [label, needle] of [
    ['橙框头像格（sao-avatar）', 'sao-avatar'],
    ['血条行（sao-hud-row）', 'sao-hud-row'],
    ['标题下的标识「DS 用户：Deepseek」', 'DS 用户：Deepseek'],
    ['卡片内余额区（sao-bal）', 'sao-bal'],
  ]) {
    if (html.indexOf(needle) === -1) bad('缺少 ' + label)
    else ok('有 ' + label)
  }
  const hudNode0 = win.children.find((c) => String(c.className).split(/\s+/).includes('sao-hud'))
  if (!hudNode0) bad('找不到顶栏 HUD')
  else {
    const hudText = hudNode0.textContent.replace(/\s+/g, ' ').trim()
    if (hudText) bad('顶栏 HUD 里还有文字（应当只有头像 + 血条）：' + hudText.slice(0, 40))
    else ok('顶栏 HUD 只含头像 + 血条（无文字）')
    if (hudNode0.querySelectorAll('img').length !== 1) bad('顶栏头像数量应为 1')
    else ok('顶栏只有 1 个头像格')
  }
  // 白色半透明风格：顶栏与血条槽都不能是黑底
  const hudRule = (cssText.match(/\.sao-hud\{[^}]*\}/) || [''])[0]
  if (!/rgba\(255,255,255,\.8/.test(hudRule)) bad('顶栏不是白色半透明：' + hudRule.slice(0, 70))
  else ok('顶栏是白色半透明（无黑底）')
  const trackRule = (cssText.match(/\.sao-hp-track\{[^}]*\}/) || [''])[0]
  if (/#2a3138|rgba\(38,45,52/.test(trackRule)) bad('血条槽还是黑底')
  else ok('血条槽不是黑底（浅色槽 + 内阴影）')
  const avatarImg = win.querySelectorAll('img').find((n) => n.parentNode && String(n.parentNode.className).includes('sao-avatar'))
  if (!avatarImg) bad('橙框头像格里没有图片')
  else ok('橙框头像格里是立绘：' + avatarImg.src)
  // 余额数值必须回到卡片里
  const balVal = win.querySelectorAll('span').find((n) => String(n.className).split(/\s+/).includes('sao-bal-val'))
  if (!balVal) bad('卡片里找不到余额数值（sao-bal-val）')
  else ok('卡片内有余额数值节点：' + balVal.textContent.trim())
  // 血条配色应当是 HUD 的黄绿，而不是之前的白灰低饱和绿
  const hpRule = (cssText.match(/\.sao-hp-fill\{[^}]*\}/) || [''])[0]
  if (!/linear-gradient\(180deg,rgba\(255,255,255,\.5\)/.test(hpRule)) bad('血条缺少 HUD 风格高光层')
  else ok('血条带 HUD 高光/斜分格叠加')

  // HUD 必须在**卡片外面**，且排在浮层最前（= 浮层自己的顶栏）
  const hudTop = win.children.find((c) => String(c.className).split(/\s+/).includes('sao-hud'))
  const bodyRow = win.children.find((c) => String(c.className).split(/\s+/).includes('sao-body-row'))
  const cardNode = win.querySelectorAll('div').find((n) => String(n.className).split(/\s+/).includes('sao-card'))
  if (!hudTop) bad('HUD 不是浮层的直接子节点（没在卡片外面）')
  else if (win.children[0] !== hudTop) bad('HUD 不是浮层第一个子节点（不在顶栏位置）')
  else ok('HUD 是浮层顶栏（直接子节点，排第一）')
  if (!bodyRow) bad('缺少 .sao-body-row 内容行')
  else if (hudTop && bodyRow.parentNode !== win) bad('内容行不在浮层下')
  else ok('内容行 .sao-body-row 与 HUD 同级')
  if (cardNode && bodyRow && cardNode.parentNode !== bodyRow) bad('卡片不在内容行里')
  else ok('卡片在内容行里（HUD 在它上方）')
  // 白+灰：卡片主体 + 灰色说明区
  if (html.indexOf('用于查看当前 DS 用户的余额状态') === -1) bad('缺少灰色说明区文案')
  else ok('灰色说明区文案在位')
  // 联结线：8 条放射 + 8 条环 + 2 个圆环
  const svgLines = win.querySelectorAll('line').length
  const svgCircles = win.querySelectorAll('circle').length
  if (svgLines < 16) bad('人物面板的联结线太少（line=' + svgLines + '）')
  else ok('人物面板联结线：' + svgLines + ' 条线 / ' + svgCircles + ' 个圆')
  if (svgCircles < 9) bad('联结线节点太少（circle=' + svgCircles + '）')
  else ok('联结线节点 + 圆环：' + svgCircles + ' 个')

  if (win.style.display !== 'none') bad('初始应当是关闭的（display=none），实际：' + win.style.display)
  else ok('初始关闭（display=none）')

  // 立绘回归检查：
  //   ① 不能再套 brightness(0)/invert —— 那会做成剪影（踩过两次）
  //   ② 贴的必须是**真的抠过图**（PNG 带 alpha 且有透明像素），否则会是一块方块
  const sil = win.querySelectorAll('img').find((n) => String(n.className).includes('sao-silhouette'))
  if (!sil) bad('找不到 .sao-silhouette 立绘节点')
  else ok('立绘节点在位：src=' + sil.src)
  const silRule = (cssText.match(/\.sao-silhouette\{[^}]*\}/) || [''])[0]
  if (!silRule) bad('CSS 里找不到 .sao-silhouette 规则')
  else if (/invert\(/.test(silRule)) bad('.sao-silhouette 里还有 invert')
  else if (/brightness\(0\)/.test(silRule)) bad('.sao-silhouette 里还有 brightness(0)（会变成剪影，用户要的是原图）')
  else ok('.sao-silhouette 只做投影、不压成剪影 ✓')

  // 真的去读 PNG：必须带 alpha 通道
  const assetPath = path.join(HERE, '..', 'assets', 'character.png')
  if (!fs.existsSync(assetPath)) bad('找不到 assets/character.png')
  else {
    const buf = fs.readFileSync(assetPath)
    const PNG_SIG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])
    const isPng = buf.slice(0, 8).equals(PNG_SIG)
    // PNG IHDR：宽(4) 高(4) 位深(1) 颜色类型(1) → 下标 25 是 colorType，6=RGBA 4=灰度+alpha
    const colorType = isPng ? buf[25] : -1
    const width = isPng ? buf.readUInt32BE(16) : 0
    const height = isPng ? buf.readUInt32BE(20) : 0
    if (!isPng) bad('assets/character.png 不是 PNG')
    else if (colorType !== 6 && colorType !== 4) bad('assets/character.png 没有 alpha 通道（colorType=' + colorType + '）')
    else ok('assets/character.png ' + width + 'x' + height + '，带 alpha 通道（colorType=' + colorType + '）')

    // 有 alpha 通道 ≠ 真的抠过图。用 Python 量一下透明像素占比（可选，设置 SAO_PYTHON 才跑）。
    const py = process.env.SAO_PYTHON
    if (py && fs.existsSync(py)) {
      try {
        const probe = execFileSync(py, ['-c',
          'from PIL import Image\n'
          + 'import numpy as np, sys\n'
          + 'a = np.asarray(Image.open(sys.argv[1]).convert("RGBA"))[:, :, 3]\n'
          + 'print(int((a <= 8).mean() * 1000))\n'
          + 'print(int((a >= 247).mean() * 1000))',
          assetPath], { encoding: 'utf8' }).trim().split(/\s+/)
        const transparent = Number(probe[0]) / 1000
        const opaque = Number(probe[1]) / 1000
        if (transparent < 0.15) bad('透明像素只占 ' + (transparent * 100).toFixed(1) + '% —— 可能没抠干净')
        else ok('抠图有效：透明 ' + (transparent * 100).toFixed(1) + '% · 实心 ' + (opaque * 100).toFixed(1) + '%')
        if (opaque < 0.2) bad('实心像素只占 ' + (opaque * 100).toFixed(1) + '% —— 人物可能被抠没了')
      } catch (err) {
        // 沙箱会拦住 Python 子进程（spawn EPERM）—— 不是抠图有问题，跳过即可
        ok('跳过抠图复核（沙箱拦住了 Python 子进程；PNG 带 alpha 已在上一条确认）')
      }
    } else {
      ok('跳过抠图复核（未设置 SAO_PYTHON）')
    }
  }

  // 右侧圆形图标列
  const orbs = win.querySelectorAll('button').filter((b) => String(b.className).includes('sao-orb'))
  if (orbs.length !== 3) bad('圆形图标数量应为 3（人物/模型/登出），实际 ' + orbs.length)
  else ok('圆形图标列 3 个：' + orbs.map((b) => b.getAttribute('aria-label')).join(' / '))
  if (orbs.length && orbs[0].getAttribute('data-state') !== 'on') bad('默认应当高亮「人物」图标')
  else ok('默认高亮第 1 个图标（人物，琥珀金）')

  // 切到模型
  if (orbs[1]) {
    orbs[1].dispatch('click')
    const mo = []
    outline(win, 0, mo)
    const mh = mo.join('\n')
    if (mh.indexOf('sao-rows') === -1) bad('模型面板没渲染出菜单行')
    else ok('模型视图渲染出菜单行（sao-rows / sao-row）')
    if (mh.indexOf('使用中 · SELECT') === -1) bad('当前模型行缺少 SELECT 态')
    else ok('当前模型行是高亮 SELECT 态')
    if (orbs[1].getAttribute('data-state') !== 'on') bad('切到模型后图标没高亮')
    else ok('切到模型后第 2 个图标高亮')
    // 二级菜单（参考图里选中图标右侧弹出的那个）—— 先切页签，再开窗
    const toggles = dom.listeners['dsh-sao:toggle'] || []
    orbs[1].dispatch('click') // 切到模型页签
    toggles.forEach((fn) => fn({ type: 'dsh-sao:toggle', detail: {} })) // 开窗
    // 从整棵树里找（二级菜单现在包在 .sao-body-row 里）
    // ⚠️ 必须按 class token 精确匹配：用 includes('sao-sub') 会先撞上 'sao-subtitle'。
    const hasClass = (n, cls) => String(n.className || '').split(/\s+/).includes(cls)
    const findNode = (root, cls) => {
      const walk = (n) => {
        for (const c of n.children) {
          if (hasClass(c, cls)) return c
          const deep = walk(c)
          if (deep) return deep
        }
        return null
      }
      return walk(root)
    }
    const subHost = findNode(win, 'sao-sub')
    const subs = subHost ? subHost.children.filter((c) => hasClass(c, 'sao-sub-item')) : []
    if (subs.length < 2) {
      bad('二级菜单没渲染（sao-sub-item 数量=' + subs.length + '）')
    } else if (subHost.style.display === 'none') {
      bad('浮层已打开但二级菜单不可见（display=none）')
    } else {
      ok('选中图标右侧渲染出二级菜单：' + subs.map((b) => b.textContent.replace(/\s+/g, ' ').trim()).join(' | '))
    }
    // 点已选中的图标不应关窗
    orbs[1].dispatch('click')
    if (win.style.display === 'none') bad('点已选中的图标把浮层关掉了（应该只重绘）')
    else ok('点已选中的图标只重绘、不关窗')
    toggles.forEach((fn) => fn({ type: 'dsh-sao:toggle', detail: {} })) // 关回去
    // 切回人物
    orbs[0].dispatch('click')
  }

  // 二级菜单每一项点了都必须有**可见**结果（否则用户只会觉得"点了没反应"）
  {
    const toggles = dom.listeners['dsh-sao:toggle'] || []
    const openWin = () => {
      if (win.style.display !== 'flex') toggles.forEach((fn) => fn({ type: 'dsh-sao:toggle', detail: {} }))
    }
    const flatNow = () => { const o = []; outline(win, 0, o); return o.join('\n') }
    const subButtons = () => {
      const hasCls = (n, cls) => String(n.className || '').split(/\s+/).includes(cls)
      const walk = (n) => {
        for (const c of n.children) {
          if (hasCls(c, 'sao-sub')) return c.children.filter((k) => hasCls(k, 'sao-sub-item'))
          const deep = walk(c)
          if (deep) return deep
        }
        return null
      }
      return walk(win) || []
    }

    // 人物页签下的两项
    orbs[0].dispatch('click')
    openWin()
    console.log('    二级菜单项（人物）：' + subButtons().map((b) => b.textContent.replace(/\s+/g, ' ').trim()).join(' | '))
    let before = flatNow()
    subButtons().forEach((b, i) => {
      b.dispatch('click')
      const after = flatNow()
      if (after === before && i === 0) bad('点「' + b.textContent.replace(/\s+/g, ' ').trim() + '」没有任何可见变化')
      else ok('点二级菜单第 ' + (i + 1) + ' 项后有可见结果')
      before = after
    })
    if (flatNow().indexOf('sao-info') === -1) bad('「信息」没有弹出信息面板（sao-info）')
    else ok('「信息」弹出了卡片内信息面板')
    // 信息面板里应当有关闭按钮，点它能退出
    const infoClose = win.querySelectorAll('button').filter((b) => b.textContent === '关闭')
    if (infoClose.length === 0) bad('信息面板没有关闭按钮')
    else {
      infoClose[0].dispatch('click')
      if (flatNow().indexOf('sao-info') !== -1) bad('点关闭后信息面板还在')
      else ok('信息面板可以关闭')
    }

    // 模型页签下的两项：每一项都要有可见反馈
    orbs[1].dispatch('click')
    openWin()
    const modelSubs = subButtons()
    console.log('    二级菜单项（模型）：' + modelSubs.map((b) => b.textContent.replace(/\s+/g, ' ').trim()).join(' | '))
    modelSubs.forEach((b, i) => {
      const b0 = flatNow()
      b.dispatch('click')
      const b1 = flatNow()
      // 反馈可以是被点亮的提示条（sao-toast[data-on]），也可以是内容变化
      const toastOn = /sao-toast/.test(b1) && /data-on="true"/.test(b1)
      if (b1 === b0 && !toastOn) bad('模型页签二级菜单第 ' + (i + 1) + ' 项点击无可见反馈')
      else ok('模型页签二级菜单第 ' + (i + 1) + ' 项点击有可见反馈' + (toastOn ? '（提示条）' : ''))
    })
    toggles.forEach((fn) => fn({ type: 'dsh-sao:toggle', detail: {} }))
    orbs[0].dispatch('click')
  }

  // 登出（第三个图标）
  const logoutOrb = orbs[2]
  if (logoutOrb) {
    logoutOrb.dispatch('click')
    const lo = []
    outline(win, 0, lo)
    const lh = lo.join('\n')
    if (lh.indexOf('LOGOUT BLOCKED') === -1) bad('登出弹框没渲染')
    else ok('登出图标弹出「LOGOUT BLOCKED」告示框')
    if (lh.indexOf('无法登出') === -1) bad('登出弹框缺少中文警示')
    else ok('登出弹框包含中文警示「无法登出」')
    const backs = win.querySelectorAll('button').filter((b) => b.textContent === '请稍候…' || b.textContent === '返回')
    backs.forEach((b) => b.dispatch('click'))
  }

  // 键盘入口
  const keydowns = dom.listeners['keydown'] || []
  if (keydowns.length === 0) bad('没有注册 keydown 监听（Ctrl+Alt+S 入口）')
  else ok('注册了 keydown 监听（Ctrl+Alt+S / Esc）')

  // 入口：右下角的完整立绘（不是小圆图标）
  const launcher = dom.all.find((n) => String(n.className).split(/\s+/).includes('sao-launcher'))
  if (!launcher) bad('没有入口元素 .sao-launcher')
  else {
    ok('入口已建出（.sao-launcher）')
    const orbImg = launcher.querySelectorAll('img')[0]
    if (!orbImg) bad('入口里没有图标图片')
    else if (orbImg.src !== '/dsh-sao/character.png') {
      bad('入口图标应当是完整立绘 character.png（实际 ' + orbImg.src + '）')
    } else ok('入口图标是完整立绘：' + orbImg.src)
    if (launcher.getAttribute('data-on') === 'false') bad('入口被显式隐藏了')
    else ok('入口常显（不依赖任何第三方挂件）')
    const bridgeFns = dom.listeners['dsh-sao:bridge'] || []
    bridgeFns.forEach((fn) => fn({ type: 'dsh-sao:bridge', detail: { text: 'no orb yet (waited 10s)' } }))
    if (!dom.all.includes(launcher)) bad('诊断事件把入口弄没了')
    else ok('桥报"no orb"时入口仍在（可见性不由桥决定）')

    // 入口点击 → 开窗。
    // ⚠ 必须让"同帧去重窗口"先过期：dsh-sao:toggle 监听器会给 frameUntil 打 120ms 时间戳，
    //   上一组用例刚触发过 toggle，紧接着点入口会被当成"重复"而跳过。
    //   （这个 120ms 窗口是防"桥 + 圆钮各 toggle 一次"的真 bug，不是可以随便去掉的东西。）
    const sleepSync = (ms) => {
      const end = Date.now() + ms
      while (Date.now() < end) { /* 离线测试里直接忙等，不引异步 */ }
    }
    sleepSync(160)
    const beforeOpen = win.style.display
    launcher.dispatch('click')
    if (beforeOpen !== 'flex' && win.style.display !== 'flex') bad('点入口没能开窗')
    else ok('点入口可以开窗')
    // 开窗后必须看得见
    const r0 = win.getBoundingClientRect()
    console.log('    info: 开窗后 display=' + JSON.stringify(win.style.display)
      + ' · left=' + JSON.stringify(win.style.left) + ' top=' + JSON.stringify(win.style.top)
      + ' rect=' + Math.round(r0.left) + ',' + Math.round(r0.top))
    if (win.style.display !== 'flex') bad('开窗后 display 不是 flex')
    else ok('开窗后 display=flex')

    // 回归：桥先派发 toggle、紧接着入口自己的处理器又跑一次 ——
    // 同一帧内必须只开合一次（真浏览器里这个 bug 表现为"点了打不开"）
    {
      win.style.display = 'none'
      const tf = dom.listeners['dsh-sao:toggle'] || []
      // 模拟桥：先派发事件（会把 frameUntil 打上），再让入口收到同一次点击
      tf.forEach((fn) => fn({ type: 'dsh-sao:toggle', detail: { source: 'click' } }))
      const afterBridge = win.style.display
      launcher.dispatch('click')   // 同一次物理点击的"第二跳"
      if (afterBridge !== 'flex') bad('桥派发 toggle 后没有开窗')
      else if (win.style.display !== 'flex') bad('同一次点击被处理了两遍（开了又关）')
      else ok('同一次点击只开合一次（桥 + 入口不会各 toggle 一遍）')
    }

    // 关键回归：把窗口拖到视口外，再开窗必须被拉回来
    const togglesR = dom.listeners['dsh-sao:toggle'] || []
    if (win.style.display === 'flex') togglesR.forEach((fn) => fn({ type: 'dsh-sao:toggle', detail: {} }))  // 先关上
    sleepSync(160)
    win.style.left = '5000px'
    win.style.top = '5000px'
    win.style.right = 'auto'
    win.style.bottom = 'auto'
    const off = win.getBoundingClientRect()
    if (off.left < 1440) bad('测试自身没把窗口推出视口（left=' + off.left + '）')
    else ok('已把窗口推到视口外（left=' + off.left + '）作为回归输入')
    togglesR.forEach((fn) => fn({ type: 'dsh-sao:toggle', detail: {} }))   // 再开
    const back = win.getBoundingClientRect()
    const inView = back.right > 24 && back.bottom > 24 && back.left < 1440 - 24 && back.top < 900 - 24
    if (!inView) bad('开窗后窗口仍在视口外（rect=' + Math.round(back.left) + ',' + Math.round(back.top) + '）')
    else ok('开窗时自动拉回视口内（rect=' + Math.round(back.left) + ',' + Math.round(back.top) + '）')
    if (typeof launcher.setPointerCapture !== 'function') bad('入口缺少指针捕获（无法拖动）')
    else ok('入口支持拖动（pointer capture 已接）')
  }
}

// 点小鲸鱼 → toggle
console.log('')
const toggleListeners = dom.listeners['dsh-sao:toggle'] || []
if (toggleListeners.length === 0) bad('没有注册 dsh-sao:toggle 监听')
else {
  ok('注册了 dsh-sao:toggle 监听')
  // 先把状态归零到「关闭」，再验证点小鲸鱼能打开（前面的面板测试可能把窗留着开着）
  const before = dom.document.querySelector('[data-sao-window]')
  if (before && before.style.display === 'flex') toggleListeners.forEach((fn) => fn({ type: 'dsh-sao:toggle', detail: {} }))
  toggleListeners.forEach((fn) => fn({ type: 'dsh-sao:toggle', detail: { source: 'click' } }))
  const w2 = dom.document.querySelector('[data-sao-window]')
  if (w2 && w2.style.display === 'flex') ok('点小鲸鱼后浮层打开（display=' + w2.style.display + '）')
  else bad('点小鲸鱼后浮层没有打开（display=' + (w2 ? w2.style.display : 'n/a') + '）')
}

// 余额渲染
console.log('')
await new Promise((r) => setTimeout(r, 60))
const w3 = dom.document.querySelector('[data-sao-window]')
if (w3) {
  const bo = []
  outline(w3, 0, bo)
  const bh = bo.join('\n')
  if (bh.indexOf('12.50') === -1 && bh.indexOf('12.5') === -1) bad('余额没有渲染出来（期望 12.50）')
  else ok('余额渲染：' + (bh.match(/[¥￥][\d.,]+/) || ['?'])[0])
  if (bh.indexOf('DSH 账号余额') === -1) bad('余额来源没有渲染')
  else ok('余额来源标注「DSH 账号余额」')
  if (bh.indexOf('满值 100.00') === -1) bad('血条比例文案缺失')
  else ok('血条显示满值比例')
}
if (fetched.length === 0) bad('没有请求 /dsh-sao/balance.json')
else ok('请求了 ' + fetched[0].split('?')[0])

// 血条分档：≥20 绿 / 10–20 黄 / <10 红（含边界）
console.log('')
console.log('血条分档（≥20 绿 · 10–20 黄 · <10 红）:')
const hpFillNode = () => dom.document.querySelector('[data-sao-window]')
  .querySelectorAll('div').find((n) => String(n.className).split(/\s+/).includes('sao-hp-fill'))
const bandOf = () => hpFillNode().getAttribute('data-band')
const footOf = () => {
  const o = []
  outline(dom.document.querySelector('[data-sao-window]'), 0, o)
  return o.join('\n')
}
const cases = [
  { amount: 50, expect: 'green' },
  { amount: 20, expect: 'green' },      // 边界：20 算绿
  { amount: 19.99, expect: 'yellow' },
  { amount: 12.5, expect: 'yellow' },
  { amount: 10, expect: 'yellow' },     // 边界：10 算黄
  { amount: 9.99, expect: 'red' },
  { amount: 0, expect: 'red' },
]
for (const c of cases) {
  mockBalance = { ok: true, totalBalance: c.amount, currency: 'CNY', source: 'account' }
  const toggles2 = dom.listeners['dsh-sao:toggle'] || []
  const w = dom.document.querySelector('[data-sao-window]')
  if (w.style.display !== 'flex') toggles2.forEach((fn) => fn({ type: 'dsh-sao:toggle', detail: {} }))
  // 打开状态下的刷新才走 renderView；这里直接触发一次余额刷新
  toggles2.forEach((fn) => fn({ type: 'dsh-sao:toggle', detail: {} }))
  toggles2.forEach((fn) => fn({ type: 'dsh-sao:toggle', detail: {} }))
  await new Promise((r) => setTimeout(r, 30))
  const got = bandOf()
  if (got !== c.expect) bad('¥' + c.amount + ' 应当是 ' + c.expect + '，实际 ' + got)
  else ok('¥' + String(c.amount).padEnd(9) + ' → ' + got)
}
// 档位文案
if (footOf().indexOf('满值 100.00') === -1) bad('档位文案里缺少满值比例')
else ok('卡片余额区显示档位 + 满值比例')

// 颜色本身：三档的渐变色必须各自不同、且是对应色系
const colorCases = [
  { amount: 50, expect: /#8fd94f/i, label: '绿色' },
  { amount: 15, expect: /#f0cc5a/i, label: '黄色' },
  { amount: 5, expect: /#ec7a68/i, label: '红色' },
]
const seenBg = []
for (const c of colorCases) {
  mockBalance = { ok: true, totalBalance: c.amount, currency: 'CNY', source: 'account' }
  const toggles3 = dom.listeners['dsh-sao:toggle'] || []
  const w = dom.document.querySelector('[data-sao-window]')
  if (w.style.display !== 'flex') toggles3.forEach((fn) => fn({ type: 'dsh-sao:toggle', detail: {} }))
  toggles3.forEach((fn) => fn({ type: 'dsh-sao:toggle', detail: {} }))
  toggles3.forEach((fn) => fn({ type: 'dsh-sao:toggle', detail: {} }))
  await new Promise((r) => setTimeout(r, 30))
  const bg = String(hpFillNode().style.backgroundImage || '')
  seenBg.push(bg)
  if (!c.expect.test(bg)) bad('¥' + c.amount + ' 的血条颜色不是' + c.label + '（' + bg.slice(0, 80) + '）')
  else ok('¥' + String(c.amount).padEnd(4) + ' → ' + c.label + ' ✓')
}
if (new Set(seenBg).size !== 3) bad('三档的血条背景没有区分（有重复）')
else ok('三档血条背景各不相同')
// 恢复默认余额，避免影响后面的用例
mockBalance = { ok: true, totalBalance: 12.5, currency: 'CNY', source: 'account' }

// 音效：开窗响「Link Start」，关窗是一声短「叮」
//
// ⚠ 音频**不在这个桩里断言** —— 原因是它测不了，不是懒得测：
//   · 频率结构（上行扫频 + 大三和弦）要看真实的振荡器调用，
//     由 browser-check.mjs 包住 AudioContext.prototype.createOscillator 在真浏览器里验；
//   · 「一次点击只响一声」是**时间驱动**的（linkStartOnce 的 400ms 去重窗口），
//     而这个桩里 `Date.now()` 几乎不前进（同步忙等），测出来的只会是假结果。
// 这里只做一条静态检查：代码里确实用 Link Start 取代了原来的 chime('open')。
console.log('')
const floatSrc = source
if (/function linkStartOnce\(/.test(floatSrc) && /function synthLinkStart\(/.test(floatSrc)) {
  ok('存在 Link Start 合成链路（synthLinkStart + linkStartOnce 去重）')
} else {
  bad('缺少 Link Start 合成链路')
}
if (/try \{ linkStartOnce\(\) \} catch \(e\) \{\}/.test(floatSrc)) {
  ok('setOpen 里接了 Link Start（不再依赖 chime(\'open\')）')
} else {
  bad('setOpen 没有接上 Link Start')
}
// 需求：**每次点击悬浮窗图标都出声**，开窗关窗都要响。
// 所以 linkStartOnce 必须落在 if (state.open) 之外，不能只在开窗分支里。
if (/try \{ linkStartOnce\(\) \} catch \(e\) \{\}\s*\n\s*if \(state\.open\) \{/.test(floatSrc)) {
  ok('每次开合都响（linkStartOnce 在开/关分支之前，开窗关窗都出声）')
} else {
  bad('linkStartOnce 只挂在开窗分支上 —— 关窗时不会出声')
}
if (!/chime\('open'\)/.test(floatSrc)) ok('旧的 chime(\'open\') 已移除')
else bad('旧的 chime(\'open\') 还在，开窗音会重复')
if (/assets|link-start/.test(floatSrc) || /ROOT \+ '\/link-start'/.test(floatSrc)) {
  ok('支持用 assets/link-start.* 替换成自备音频')
} else {
  bad('没有自备音频的入口')
}
// 播放时不能拿 readyState 当门槛（真浏览器实测：点击时常常只有 rs=1）
if (/readyState < 2\) return false/.test(floatSrc)) {
  bad('playLinkEl 仍在用 readyState 当门槛 —— 点击时会不出声')
} else {
  ok('playLinkEl 不拿 readyState 当门槛（点击即可播，play() 自己会等缓冲）')
}

// 离线测试里的同步等待：用来跨过"同一次点击去重窗口"（120ms），
// 否则紧接着的合法点击会被当成重复而被忽略。
const sleepSync = (ms) => { const end = Date.now() + ms; while (Date.now() < end) { /* busy wait */ } }

// 回归：一次 toggle 必须真的改变显示状态（曾经因为"先改 display 再调 setOpen"，
// 导致 setOpen 里 isOpen() 重算 was === next，整个开窗分支被跳过 ——
// 表现就是"点了有音效、界面却像没反应"）
console.log('')
{
  const doT = () => toggleListeners.forEach((fn) => fn({ type: 'dsh-sao:toggle', detail: {} }))
  const w = dom.document.querySelector('[data-sao-window]')
  if (w.style.display === 'flex') { doT(); sleepSync(160) }
  const before = w.style.display
  doT()
  if (w.style.display === before) bad('一次 toggle 没有改变显示状态（开窗分支可能被跳过）')
  else ok('一次 toggle 改变显示状态：' + JSON.stringify(before) + ' → ' + JSON.stringify(w.style.display))
  sleepSync(160)
  doT()   // 关回去
}

console.log('')
// 再执行一次同一份脚本（模拟第二个注入通道）
try {
  new Function('window', 'document', 'fetch', 'setTimeout', 'clearTimeout', 'setInterval', 'clearInterval', 'CustomEvent', source)(
    dom.window, dom.document, globalThis.fetch, setTimeout, clearTimeout,
    () => 1, () => {}, globalThis.CustomEvent,
  )
  ok('第二次载入没有抛错')
} catch (err) {
  bad('第二次载入抛错', err)
}
const winsAfter = dom.all.filter((n) => n.attributes && n.attributes['data-sao-window'])
const liveWins = winsAfter.filter((n) => !n.removed)
const stylesAfter = dom.all.filter((n) => n.tagName === 'STYLE' && !n.removed)
const listenersAfter = (dom.listeners['dsh-sao:toggle'] || []).length
if (stylesAfter.length !== 1) bad('样式表应当只剩 1 个，实际 ' + stylesAfter.length)
else ok('样式表只剩 1 个（旧的被摘掉）')
if (listenersAfter !== 1) bad('toggle 监听应当只剩 1 个，实际 ' + listenersAfter + '（旧的没摘干净）')
else ok('toggle 监听只剩 1 个（旧实例已销毁）')
if (liveWins.length > 1) bad('DOM 里挂着 ' + liveWins.length + ' 个浮层')
else ok('DOM 里只挂 1 个浮层（共创建 ' + winsAfter.length + ' 个，旧的已移除）')
if (typeof dom.window.__dshSaoFloatDestroy !== 'function') bad('没有暴露 __dshSaoFloatDestroy')
else ok('暴露 __dshSaoFloatDestroy')

// 自愈之后仍然能正常开合 + 余额照常渲染
const tl2 = dom.listeners['dsh-sao:toggle'] || []
const wNow = dom.document.querySelector('[data-sao-window]')
if (wNow && wNow.style.display === 'flex') tl2.forEach((fn) => fn({ type: 'dsh-sao:toggle', detail: {} }))
tl2.forEach((fn) => fn({ type: 'dsh-sao:toggle', detail: {} }))
const wAfter = dom.document.querySelector('[data-sao-window]')
if (wAfter && wAfter.style.display === 'flex' && wAfter.parentNode) ok('自愈后仍能正常开窗（display=flex 且挂在 DOM 上）')
else bad('自愈后开窗失效（display=' + (wAfter ? wAfter.style.display : 'n/a') + '）')
await new Promise((r) => setTimeout(r, 40))
const bo2 = []
outline(wAfter, 0, bo2)
if (bo2.join('\n').indexOf('12.50') === -1) bad('自愈后余额没渲染（活着的可能是残骸实例）')
else ok('自愈后余额照常渲染（活着的是新实例）')

console.log('')
console.log(failures === 0 ? '全部通过 \u2713' : failures + ' 项失败 \u2717')
process.exit(failures === 0 ? 0 : 1)
