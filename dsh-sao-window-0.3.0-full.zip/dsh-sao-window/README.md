# dsh-sao-window · DSH 悬浮窗插件

刀剑神域（SAO）游戏 UI 风格的 DSH 悬浮窗：**点一下右下角的头像圆钮**就打开/收起。

> **完全独立**：不依赖 `dsh-whale-widget`，也不去找任何第三方挂件的 DOM。
> 入口圆钮由本插件自己建在页面右下角，图标就是抠好的头像特写（`assets/head.png`）。
> 圆钮可以拖动，位置记在 `localStorage`。

```
  ╔═ 顶栏 HUD（卡片外面，白色半透明）══════════════════════════╗
  ║  ┌────┐  ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓░░░░░░░░░░░░░░░░░░░░░░░  ║   ┌────┐
  ║  │头像│                                                ║   │人物│ ← 琥珀金选中
  ║  └────┘ 橙框                                            ║   ├────┤
  ╚═════════════════════════════════════════════════════════╝   │模型│
  ┌─ 人物 ───────────────┐                                      ├────┤
  │ DS 用户：Deepseek     │                                      │登出│
  ├──────────────────────┤   ┌─ MODEL ───────────┐              └────┘
  │ HP · 余额    ¥12.50   │   │ ◉ 使用中  SELECT │ ← 二级菜单
  │ DSH 账号余额 / 满值 14%│   │ ⌾ 切换模型 /model│
  ├──────────────────────┤   └───────────────────┘
  │  ┌────────────────┐  │                        ╭──────╮
  │  │  ✦──✦──✦──✦   │  │                        │ 头像 │ ← 右下角入口圆钮
  │  │   │  立绘  │    │  │                        ╰──────╯
  │  │  ✦──✦──✦──✦   │  │
  │  └────────────────┘  │
  ├──────────────────────┤
  │ 用于查看当前 DS 用户的余额状态 │
  └──────────────────────┘
```

**入口**：右下角 **56px 圆钮**（白底 + 橙描边 + 头像抠图，hover 微抬、可拖动）。
另有 `Ctrl+Alt+S` 键盘开合与 `data-sao-open` 通用入口。

**顶栏 HUD**（参考图三的 Minecraft 血条）：**独立于卡片、横跨整个浮层顶部**，
**只放两样东西** —— 左侧橙框头像格（`head.png`）与右侧血条本体。

- 风格是**白色半透明**（`rgba(255,255,255,.88)` + 背景模糊），**不用黑色底框**
- 血条是**浅色底槽 + 渐变填充**，带内阴影、顶部高光、斜分格与 15px 分段竖线，白底上也有立体感
- **按余额金额分三档取色**（离散档位，不是连续渐变）：

  | 余额 | 颜色 | 色阶 |
  |---|---|---|
  | **≥ ¥20** | 绿色 | `#8fd94f → #5fb02f` |
  | **¥10 – 20** | 黄色 | `#f0cc5a → #d9a01c` |
  | **< ¥10** | 红色 | `#ec7a68 → #c23b2a` |

  当前档位同时挂在 `data-band="green|yellow|red"` 上（便于自检与外部脚本读取），
  卡片余额区显示对应文案（`余额充足` / `余额偏低` / `余额告急`）。
  条长仍按 ¥100 折算，与颜色分档相互独立。
- 顶栏里**不放任何文字**（金额、来源、Lv 全都不在这儿）

**人物视图**（默认）：标题下的标识 `DS 用户：Deepseek`；内容区从上到下是
**卡片内余额区**（`HP · 余额` + 金额 + 来源/满值比例）→ 立绘 + **放射状联结线与节点**。

**模型视图**（参考图二的悬浮菜单条）：菜单条列表，当前模型行是**高亮金色 + 左侧黄色箭头**的
「使用中 · SELECT」态，另一行是「切换模型」入口。

**右侧圆形图标列**（参考图二）：灰底细环白圆 + 灰字形；选中的图标变成**琥珀金**并带外发光。
第 1 个=人物，第 2 个=模型，第 3 个=登出。

**二级菜单**：选中图标的右侧弹出白底小卡片（人物页签：`信息` / `余额明细`；模型页签：`当前模型` / `切换模型`）。
**每一项点了都有可见结果** —— `信息` 打开卡片内的信息面板，`余额明细` 刷新余额并弹提示条，
`切换模型` 弹提示条告诉你用 `/model`。（这里踩过坑：最初只往左下角诊断标记写一行，用户点了等于没反应。）

**人物立绘**：`assets/character.png` 是**已经抠掉背景的透明底立绘**，在面板里按原色贴上去
（只加一层柔和投影），叠在浅灰光晕与 8 节点放射联结线之上。

⚠️ **不要给立绘套 `brightness(0)` / `invert`** —— 那会把它变成剪影。这个坑踩过三次：
`invert(1)` 出来的白剪影在 `#fafbfb` 近白底上**隐形**；换成 `brightness(0)` 实心剪影又不是要的效果。
现在自检直接断言 `.sao-silhouette` 规则**不含**这两个滤镜。

### 换立绘 / 重新抠图

原图（带背景）留在 `assets/character.original.png`。换一张新立绘时，一条命令同时产出
**完整人物**与**头像特写**：

```powershell
python scripts/extract-character.py <带背景的图> assets/character.png assets/head.png 760 256
```

脚本做法（保守、保内部细节）：

1. 背景色按**四条边内侧**中位数取（比只看四角稳）；
2. 阈值**自适应** —— 背景可能是 `#F0F0EE` 这种带灰的白，写死阈值会在人物周围留一圈灰雾；
   这里从 diff 直方图里找背景峰的右边界，夹在 `[18, 60]`；
3. **只从图像外圈做 flood fill** —— 只把与边缘连通的区域判为背景，
   人物内部与背景同色的浅色区域（高光、星星、眼睛亮部）因此被保住；
4. 边缘带按「离背景色的距离」做 Alpha 过渡并略微压暗，消掉白描边留下的灰边；
5. 头像特写用**不透明包围盒 + 可调比例**切（`side_f` / `center_y_f` / `head_range_f`），
   不用启发式找"头顶"—— **呆毛那根细线会把自动检测拉到画面最上沿**，启发式必然失手（踩过）。

⚠️ 头像**必须在缩放到目标高度之后**再切，否则比例对不上坐标系（踩过：
在源图分辨率上按比例切，结果头像跑到画面外）。

自检会读 PNG 头确认 `colorType=6`（真带 alpha）；设置 `SAO_PYTHON` 时还会用 Python
复核透明像素占比（避免「有 alpha 通道但其实全不透明 = 一块白方块」）。

整体：白色卡片 + 灰色说明区 + 细分隔线 + 卡片右缘指向图标列的三角缺口。

## 三个入口

| 入口 | 说明 |
|---|---|
| **右下角完整立绘** | 主入口。**抠好的完整人物立绘**（`assets/character.png`，透明底）直接站在右下角，不加圆底/方框，只带柔和投影；hover 上浮 + 橙色描边光；**可拖动**（位置记 `localStorage`） |
| **`Ctrl+Alt+S`** | 键盘快捷键备用入口；`Esc` 关闭浮层（先关信息面板，再关整窗） |
| **`data-sao-open`** | 任何带这个属性的元素点一下就开（方便自己或其它插件加入口按钮） |

### 入口 / 开合踩过的坑（都已被自检钉住）

**① ⚠ 一次点击只能开合一次 —— 桥和入口不能各 toggle 一遍。**
点击桥是「capture 监听 → `fire('click')` → 自定义事件 `dsh-sao:toggle` → 浮层监听器 `toggle()`」，
而入口自己的 `click` 处理器**也会** `toggle()`。两条路都开了同一次点击，结果就是
`setOpen(true)` 紧随 `setOpen(false)` —— **窗口开了又立刻关掉，表现正是"点图标打不开"**。

真浏览器实测抓到的原始记录：

```
marker = sao: 2 setOpen(true) 进入 | 3 setOpen 完成 state.open=true
       | 1 点击到达 | 2 setOpen(false) 进入 | 3 setOpen 完成 state.open=false
```

现在有两道防线，任一单独都能挡住：

1. 桥绑定时会在入口上打 `data-sao-bridged="1"`，入口的处理器看到就不再 toggle；
2. 浮层收到 `dsh-sao:toggle` 时记一个 **120ms 去重窗口**，入口处理器在同一窗口内不再 toggle。
   —— 这条不依赖桥是否配合打标记，**因为宿主不热重载、`bridge.js` 与 `float.js` 版本可能不同步**（这个坑真踩过：
   浮层脚本是热读的，桥是启动时注入的，只改桥的话当前会话里根本没生效）。

去重窗口取 120ms 而不是 200ms：200ms 会误吞用户的连点（实测过）。

**② 不要在调用 `setOpen()` 之前先改 `display`。**
`setOpen()` 内部会用 `isOpen()`（读 `win.style.display`）重算 `was`。若调用方先把
`display` 设成目标值，`was` 就等于目标值，于是整个开窗分支
（音效 / 拉回视口 / 刷新余额）**被整段跳过** —— 表现也是"点了有音效、界面却没反应"。
现在 `toggle()` 只做 `setOpen(!isOpen())`，兜底改写放在 `catch` 里。

**③ `ensureVisible()` 必须在内容渲染进 DOM 之后才调用。**
否则量到的尺寸是 0x0 或上一版内容，会把一个本来就在右下角的窗口误判成"越界"然后搬走。
（真浏览器截图里窗口跑到屏幕中间过。）

**④ 每次开窗都要把浮层拉回视口内**，入口自身的 `localStorage` 坐标在还原时也要夹回视口 ——
否则"被拖到屏幕外再刷新"就永远点不到了。

**⑤ 点击链整体 try/catch 并把异常写进诊断标记。** 副作用任何一处抛错都不该让"窗口出现"本身失败。

## 三个按键（右侧圆形图标列）

| 图标 | 行为 |
|---|---|
| **人物** | 默认视图。立绘（`assets/character.png`）+ 联结线；余额在**卡片内余额区**，顶栏 HUD 只放头像与血条 |
| **模型** | 从 composer 的模型位读出当前模型名并以 SELECT 行展示，另一行给出切换入口提示（`/model`）。**只做显示，不去争抢 DSH 的模型状态** |
| **登出** | 弹出 SAO 式「登出受阻」告示框：逐行播放 `LOGOUT 请求已发出… → 解除 NERvGear 连接… OK → !! LOGOUT 被系统拒绝 —— 本机无法登出`，红色警示 +「无法登出」。纯氛围彩蛋，**不影响真实 DSH**，动画走完即可关闭 |

拖拽手柄挂在**卡片标题**上（拖标题 = 拖整个浮层）；`✕` 关闭；打开时自动刷新余额，之后每 60 秒刷新。

## 余额怎么取（与「设置 → 账号与余额」同口径）

`GET /dsh-sao/balance.json`：

1. **优先 `DEEPSEEK_API_KEY`** → `https://api.deepseek.com/user/balance`，取 `balance_infos` 里的 CNY 项 `total_balance`（冷启动凭据未就绪会重试一次）。
2. **没有 key 就退回 DSH 账号登录态** → `ctx.deepseekAccount.getBalance()`，金额 = **充值钱包 + 赠金钱包**（与 `total_balance` 同义）。
3. 两者都不可用 → 血条显示「余额不可用」，鼠标悬停给出原因。

血条满值按 **¥100.00** 折算；颜色按金额分三档（见上）；卡片余额区显示 `来源 · 档位 · 满值 100.00 · N%`。

## 三个入口

| 入口 | 说明 |
|---|---|
| **右下角完整立绘**（`.sao-launcher`） | 主入口。抠好的**完整人物立绘**（透明底）直接站在右下角，无圆底/方框，只带柔和投影；hover 上浮 + 橙色描边光；**可拖动**（位置记 `localStorage`） |
| **`Ctrl+Alt+S`** | 键盘开合；`Esc` 关闭浮层（先关信息面板，再关整窗） |
| **`data-sao-open`** | 任何带这个属性的元素点一下就开，方便自己或别的插件加入口 |

> **为什么不再用小鲸鱼**：早先版本把入口挂在 `dsh-whale-widget` 的立绘上，
> 结果一旦那个挂件没装/被禁用/bundle 声明从 profile 里丢失，点击入口就整个失效
> （这个坑真踩过：手工重写 profile 的 `package.json` 时漏掉 `dsh-whale-widget`，
> 4 条 `/dsh-whale/*` 路由全 404，图标没了、`findWhale()` 也找不到目标）。
> 现在入口由本插件自持，**与任何第三方挂件无关**。

诊断标记：`sao: ready (click the orb · Ctrl+Alt+S)`，桥接上入口后显示 `sao: bridge: orb bound`。

## 点击音效「Link Start」

**每次点击悬浮窗**（开窗）都会响一次接入音效。取值顺序：

1. **自备音频** `assets/link-start.ogg | .mp3 | .m4a | .wav`（按此顺序取第一个存在的）
2. 没有就回退到**内置合成音**（WebAudio 实时合成，见下）

当前仓库里放的是 **`assets/link-start.m4a`**（1.35 秒）—— 由用户提供的 MP4 提取而来，
见下面「从 MP4 提取音频」。

启动日志会写明用的哪个：

```
[dsh-sao-window] 开场音：使用自备音频 link-start.m4a
[dsh-sao-window] 开场音：内置合成音（把 link-start.ogg/mp3/m4a/wav 放进 assets/ 可替换）
```

### 内置合成音（回退用）

| 层 | 内容 |
|---|---|
| ① 上行扫频 | `sawtooth` + `sine`，180 Hz → 2100 Hz，0.5s（把"启动"推上去） |
| ② 到顶的「叮」 | 2093 Hz → 2637 Hz；叠一层 4186 Hz 三角波 |
| ③ 明亮大三和弦 | A5 `880` / C#6 `1108.7` / E6 `1318.5`，各带轻微 detune |
| ④ 低音垫 | 110 Hz → 82.4 Hz，给一个沉稳收束 |

总长约 1.7 秒。真浏览器实测（`browser-check.mjs` 包住 `createOscillator` 数出来的）：

```
oscillators = 8
freqs = 180, 180, 2093, 4186, 880, 1108.7, 1318.5, 110
        └扫频┘  └─叮─┘ └── 大三和弦 ──┘      └低音┘
```

### 从 MP4 提取音频

这台机器上**没有 ffmpeg**，Python 侧也没有 `soundfile` / `pydub` / `av`（标准库 `wave`
只认 WAV），所以自己写了一个无损提取器：

```powershell
python scripts/extract-mp4-audio.py <输入.mp4> assets/link-start.m4a
```

它**不做任何编解码**：MP4 的音轨本来就是 AAC 采样帧，只要重算采样表
（`stsz` / `stsc` / `stco`）把 chunk 搬到新容器、改写 chunk offset 即可，**音质无损**，
产物是浏览器原生支持的 AAC-in-MP4（`.m4a`）。视频轨整个丢掉。

⚠️ **默认丢弃全部元数据**（`udta` / `meta` / `ilst`）。这不是洁癖 ——
剪辑软件会在里面写进"属于你自己的"东西。实测一份剪映导出的 mp4 里就有：

| 字段 | 值 | 性质 |
|---|---|---|
| `videoId` | `130f3609-…-4cbabcb2bb5a` | **项目唯一 ID** |
| `product` / `source_type` | `lv` / `douyin_beauty_me` | 剪映，且标记用了美颜 |
| `is_use_vc_sing_clone` | `1` | 用过声音克隆 |
| `os` | `windows` | — |

这些跟音频播放毫无关系，却会跟着插件一起被推上公开仓库。真要保留就加 `--keep-metadata`。

实测（一段含视频轨 + AAC 音轨的 MP4 → `link-start.m4a`）：

```
音频轨 stbl 里的表: stsd(126) stts(24) stsc(448) stsz(256) stco(176) sgpd(26) sbgp(28)
stsz: sample_size=0 count=59  ·  stco: 40 个 chunk  ·  stsc: 36 条
音频：40 个 chunk · 59 个样本 · stsz 里 59 条
抽取音频字节 32254 字节 → 写出 34784 字节
```

真浏览器验证：`readyState=4`、`duration=1.346 秒`、**`oscillators=0`**（确实用自备音频、
没有退回合成音）、未静音 `play()` 恰好 1 次。

### 只响一声

点击桥与入口处理器是两条独立的路，所以：

- `linkStartOnce()` 带 **400ms 去重窗口** —— 一次物理点击不会叠着响两遍；
- `stopLink()` 在下一声开始前打断上一声；
- 预热用**单独的一次性 muted 元素**（`prewarmLinkAudio`），不碰主元素 ——
  否则"一次点击播了几次"就数不清了（真浏览器实测抓到过 `playCalls=2`）。
- 自备音频**优先**：还没就绪就等它（就绪后由 `canplaythrough` 补播），
  而不是立刻回退合成音 —— 否则网络稍慢就会"该用你的音频却响了合成音"。

## 架构：为什么是「宿主 + 页面脚本」

```
lib/index.js          宿主半侧：5 条 HTTP 路由 + 双通道注入（tapIndex + index-inject）
lib/float.js          浏览器半侧：原生 DOM 自建浮层 + 右下角圆钮（由 /dsh-sao/float.js 下发）
                      /dsh-sao/bridge.js：把圆钮的点击翻译成 window 事件 dsh-sao:toggle
assets/character.png  人物立绘（抠好的透明底，人物栏用）
assets/head.png       头像特写（右下角圆钮 + 顶栏 HUD 头像格用）
```

浏览器半侧**刻意不使用 DSH 的客户端模块系统**（`dsh.client` + `shell.overlay` 插槽），
而是照 `dsh-whale-widget` 的做法由宿主注入成页面 `<script>`。原因：走客户端模块系统时，
`dsh.client.inject` 是「浏览器 bundle 的加载图」，只能写**带 `/client` 入口**的包；
一旦写进只有宿主半侧的包（例如 `@deepseek-ai/dsh-client-ui-slots` —— 它只提供
`ctx.slots` 服务、没有 `lib/client.js`），这条 entry 会永远组装不出来、界面完全不出现，
而宿主半侧一切正常 —— **这个坑真踩过，而且从外面完全看不出原因**（插件列表甚至显示 active）。

### 注入只走一个通道（tapIndex）

曾经同时挂了 `tapIndex` + `webserver/index-inject`（照 dsh-whale-widget 那套双通道），
结果 `float.js` 被**执行了两次**：两个模块实例、两个 `dsh-sao:toggle` 监听、两个 `win` 节点
（只有后 append 的那个在 DOM 里）。症状就是「点小鲸鱼没反应」或「开了但里面是空的」，
而且查起来极其隐蔽。现在只保留 `tapIndex`，并把「只挂 1 个 tapIndex」写进了自检断言。

## 安装

`link:` 装法（开发时最方便，改动即时可见）：

```powershell
# 把 <插件目录> 换成你 clone 下来的实际路径
dsh plugin --profile desktop add link:"<插件目录>/packages/dsh-sao-window"
```

`link:` 是软链安装 —— **装完不要移动/改名这个目录**，移动了要重新 add 一次。

装完后确认 profile 的 `package.json` 里两处都对：

```jsonc
{
  "dependencies": { "dsh-sao-window": "link:<插件目录>/packages/dsh-sao-window" },
  "dsh": { "profile": { "bundles": [
    "@deepseek-ai/dsh-base",
    "@deepseek-ai/dsh-web-app",
    "dsh-sao-window"          // ← 必须有这一行，否则宿主半侧不会加载
  ] } }
}
```

> ⚠️ **两处都要有**：只写 `dependencies` 而漏掉 `bundles`，插件不会加载；
> 只写 `bundles` 而漏掉 `dependencies`，模块解析不到。
> 手工编辑这个 `package.json` 时也**别把别的插件条目删掉**（踩过：
> 漏掉 `dsh-whale-widget` 导致那个挂件整个不加载）。

## 生效方式（重要）

| 改了什么 | 生效方式 |
|---|---|
| `lib/float.js`（悬浮窗 UI） | 宿主按 mtime 热读取 → **硬刷新页面**（Ctrl+F5）即可 |
| `lib/index.js`（宿主半侧：路由、余额源、注入行） | **宿主半侧在启动时一次性加载，改完必须重启客户端**（实测：新增探针路由在运行中的实例里始终 404） |
| `package.json` 的 `dsh.profile.bundles` | 同上，重开客户端 |

## 自检

```powershell
# 1) 宿主路由是否注册（无需会话；401/403 也算「路由在」）
node scripts/probe-routes.mjs
node scripts/probe-routes.mjs http://127.0.0.1:3087   # 指定地址

# 2) 悬浮窗 UI 离线验证（不需要浏览器，也不需要装插件）
node scripts/verify-float.mjs

# 3) 宿主半侧加载 + 注入行内容
node scripts/host-smoke.mjs lib/index.js
```

页面里还可以看**左下角诊断标记**：正常会依次出现

```
sao: ready (click the whale)     ← 脚本已到页面、浮层已建好
sao: toggle received             ← 点小鲸鱼的事件到了
sao: window open                 ← 浮层已展开
```

看不到这个标记，就说明 `/dsh-sao/float.js` 没被注入或没执行（先看第 1 步的路由）。
想关掉标记：删掉 `lib/float.js` 里的 `stage(...)` 调用即可。

## 卸载 / 回滚

```powershell
dsh plugin --profile desktop remove dsh-sao-window   # 桌面端：交给客户端里的 DSH 执行
dsh plugin --profile web remove dsh-sao-window       # Web 版
```

插件对 DSH 本体是**零侵入**：4 条自己的 `/dsh-sao/*` 路由 + 一行 index 注入。
卸载后全部随之撤销；不写任何全局状态、不改任何 DSH 文件。

## 安全边界

本插件的路由**直接由宿主 webServer 处理，宿主不会替插件做来源校验**
（实测：带 `Sec-Fetch-Site: cross-site` 或伪造 `Origin` 也拿到 200 —— 而
`dsh-whale-widget` 的同类路由返回 401）。所以插件自带一层 fail-closed 校验：

- Host 必须是回环（`localhost` / `127.0.0.0/8` / `::1`），否则 403；
- `Sec-Fetch-Site: cross-site` 一律 403；
- 带 `Origin` 时必须与 Host 同源，否则 403。

部署在非回环地址（反向代理 / 局域网）时，用环境变量
`DSHS_WINDOW_TRUSTED_HOSTS` 显式声明允许的 Host（逗号分隔、可带端口），默认空。

## 目录结构

```text
dsh-sao-window/
├── package.json          # DSH bundle 声明（dsh.bundle.patch）
├── cordis.patch.yml      # 挂载声明
├── lib/
│   ├── index.js          # 宿主半侧：余额源 + 资源路由 + index 注入 + 自检页
│   └── float.js          # 浏览器半侧：原生 DOM 浮层 + 右下角立绘入口 + 诊断标记
├── assets/
│   ├── character.png          # 抠好的透明底完整立绘（面板 + 右下角入口都用它）
│   ├── head.png               # 头像特写（顶栏 HUD 头像格用）
│   ├── link-start.m4a         # 开场音（自备；无则回退内置合成音）
│   └── character.original.png # 带背景的原图（备用）
├── scripts/
│   ├── browser-check.mjs     # ★ 真实浏览器自检：Chrome + CDP，真的去点入口、验音频
│   ├── verify-float.mjs      # 离线验证：在最小 DOM 沙箱里真跑 float.js
│   ├── host-smoke.mjs        # 离线验证：加载宿主半侧，检查注入与 6 条路由
│   ├── bridge-check.mjs      # 离线验证：桥运行时语法 + 自愈 + 样式规则
│   ├── extract-character.py  # 抠图：从浅灰白底立绘里切出透明底人物 + 头像特写
│   ├── extract-mp4-audio.py  # 从 MP4 无损提取音轨 → .m4a（无 ffmpeg 时用）
│   └── probe-routes.mjs      # 运行期路由自检
└── README.md
```

## 自检怎么跑

```powershell
# 离线三套（快，无需浏览器）
node scripts/host-smoke.mjs lib/index.js
node scripts/verify-float.mjs
node scripts/bridge-check.mjs

# 真实浏览器（Chrome + CDP；起一个随机端口的同源代理来喂资源，绕开 DSH 登录）
node scripts/browser-check.mjs                  # 完整链路（含 bridge.js，用 assets/ 里的自备音频）
node scripts/browser-check.mjs --noaudio        # 模拟"不带自备音频"→ 必须回退合成音
node scripts/browser-check.mjs --nobridge       # 对照实验：只有 float.js
node scripts/browser-check.mjs --shot out.png   # 顺便存证截图（默认写系统临时目录）

# 发布前隐私审计
node scripts/privacy-audit.mjs
```

`browser-check.mjs` 会**真的派发一次点击**，并断言：
每次点击各响一声、点完 `display=flex`、`getComputedStyle` 可见、
窗口在视口内、卡片内容非空、顶栏 HUD 与立绘在位、音频走的是自备文件还是合成音、页面无 JS 报错。

> **为什么非得上真浏览器**：手写假 DOM 的 `getBoundingClientRect()` 曾经返回固定值，
> 等于"假装位置永远正确"，把"窗口跑到视口外""图片加载失败""一次点击 toggle 两遍"
> "点击时音频 readyState 还没到 2 → 不出声"这几类 bug **全遮住了**。
> 那个"开了又关"的 bug 就是 `browser-check` 第一次跑出来的。

## 发布前检查（重要）

```powershell
node scripts/privacy-audit.mjs
```

它会查：本机用户名/家目录绝对路径、疑似 API key、token/密码、真实余额数字、
个人文件名、**二进制资产里的软件元数据**（`udta`/`ilst`/`editType`/`videoId`…）、
以及自检产物残留（截图像会把余额一起拍进去，`.gitignore` 已忽略）。

### ⚠️ 分享/上传前请自行决定这两件事

1. **`assets/link-start.m4a` 是你提供的音频**，版权归原权利人。
   要公开分发建议**删掉这个文件** —— 删掉后会自动回退到内置合成音，功能不受影响
   （`package.json` 的 `files` 里也已经不含它）。
2. **`assets/character.original.png` / `character.png` / `head.png` 立绘**同理，
   请确认你有权分发；不确定就换成自己的图或占位图。
   替换后跑一次 `scripts/extract-character.py` 重新生成抠图与头像即可。

## 已知限制

- 「02 模型」只**显示**当前模型名（从 composer 的模型位读取），切换走 DSH 自带入口 ——
  这样避免和 `ui-model-selection` 争抢同一份会话级模型状态。
- 「03 登出」是氛围彩蛋，不真的登出、也不阻塞 DSH 的任何操作。
- 余额血条按固定满值 ¥100 折算，仅作视觉映射，不代表任何额度或预算。
- 左下角的 `sao:` 诊断标记默认开启，确认无误后可自行删除。
